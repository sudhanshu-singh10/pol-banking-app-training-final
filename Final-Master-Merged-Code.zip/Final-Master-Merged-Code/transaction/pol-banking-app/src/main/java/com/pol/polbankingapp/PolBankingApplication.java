package com.pol.polbankingapp;

import com.pol.polbankingapp.model.request.AccountCreation.FinanceInstInfo;
import com.pol.polbankingapp.model.request.PaymentTransfer;
import com.pol.polbankingapp.model.request.payment.Accounts;
import com.pol.polbankingapp.model.request.payment.Balance;
import com.pol.polbankingapp.model.response.AccountResponse.AccountInfo;
import com.pol.polbankingapp.repository.BalanceCSV;
import com.pol.polbankingapp.repository.MasterAccount;
import com.pol.polbankingapp.service.PaymentServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

@SpringBootApplication
public class PolBankingApplication {

//    @Autowired
//    static PaymentServiceImpl paymentService;
//    @Autowired
//    static PaymentTransfer paymentTransfer;

    public static void main(String[] args) throws IOException, JAXBException {
        SpringApplication.run(PolBankingApplication.class, args);
//        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
//        LocalDateTime date = LocalDateTime.now();
//        PaymentTransfer paymentTransfer=new PaymentTransfer();
//        paymentTransfer.setAmount(100);
//        paymentTransfer.setBicfi("");
//        paymentTransfer.setCreditoracc("17454316444");
//        paymentTransfer.setDebtoracc("29587273658");
//        paymentTransfer.setDate(date);
//        paymentTransfer.setMethod("");
//        paymentTransfer.setNote("");
//        PaymentServiceImpl paymentService = new PaymentServiceImpl();
//        paymentService.intiateTranscation(paymentTransfer);

    }

}
