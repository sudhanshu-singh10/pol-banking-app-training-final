package com.pol.polbankingapp.model.response.payment;

import com.pol.polbankingapp.model.request.payment.Balance;
import lombok.Data;
import lombok.ToString;

import java.util.List;

@Data
@ToString
public class TranscationDetailsBetweenDates {
    List<Balance> transcationsDetails;
}
