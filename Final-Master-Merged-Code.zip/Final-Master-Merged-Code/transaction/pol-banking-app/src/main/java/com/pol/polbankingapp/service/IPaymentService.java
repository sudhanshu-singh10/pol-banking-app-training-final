package com.pol.polbankingapp.service;

import com.pol.polbankingapp.model.request.PaymentTransfer;
import com.pol.polbankingapp.model.response.payment.FIToFICstmrCdtTrf;
import com.pol.polbankingapp.model.response.payment.TranscationDetailsBetweenDates;

import javax.xml.bind.JAXBException;
import java.io.IOException;

public interface IPaymentService {
   public String intiateTranscation(PaymentTransfer paymentTransfer) throws IOException, JAXBException;
   public FIToFICstmrCdtTrf transactionDetailsbyid(String endToEndId);
   //public  FIToFICstmrCdtTrf transactionFileGeneration(FIToFICstmrCdtTrf ob) throws JAXBException;
   public TranscationDetailsBetweenDates getTransctaionDetailsBetweenDates(String accountid,String fromDate, String toDate) throws Exception;

}