package com.pol.polbankingapp.model.response.AccountResponse;

//import com.pol.polbankingapp.service.MapAdapter;
import com.sun.xml.txw2.annotation.XmlAttribute;
import lombok.Data;
import org.springframework.stereotype.Component;

import javax.xml.bind.annotation.*;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
@XmlRootElement(name ="Accounts")
@XmlAccessorType(XmlAccessType.FIELD)
@Data
public class MasterAccounts {

    //@XmlElementWrapper(name = "AccountInfo")
    //private List<MasterAccountInfo> accountInfo;

    //@XmlTransient
    //@XmlElement(name="AccountInfo")
    private Map<String, MasterAccountInfo> masterMap;

//    @XmlJavaTypeAdapter(MapAdapter.class)

    public Map<String, MasterAccountInfo> getMasterAccountMap() {
        return masterMap;
    }

    public void setMasterAccountMap(Map<String, MasterAccountInfo> masterMap) {
        this.masterMap = masterMap;
    }

}