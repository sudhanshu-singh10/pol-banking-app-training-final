package com.pol.polbankingapp.controller;

import javax.validation.Valid;
import javax.xml.bind.JAXBException;

import com.pol.polbankingapp.service.UserServicesImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.pol.polbankingapp.model.request.AccountCreation.User;
import com.pol.polbankingapp.repository.AccountCreation;
import com.pol.polbankingapp.service.UserServices;

import java.io.IOException;

@RestController
public class AccountController {


    @Autowired
    private UserServicesImpl userService;

    @PostMapping(path ="/v1/accounts", consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<User> createAccount(@Valid @RequestBody User userac) throws JAXBException, IOException {
    	  userService.createAccount(userac);
      
        return new ResponseEntity<User>(HttpStatus.CREATED);
    }

	
}
