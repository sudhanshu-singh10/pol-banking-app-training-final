package com.pol.polbankingapp.repository;

import com.pol.polbankingapp.model.response.AccountResponse.AccountInfo;
import com.pol.polbankingapp.model.response.AccountResponse.Customers;
import com.pol.polbankingapp.model.response.AccountResponse.Customers;
import com.pol.polbankingapp.service.UserServicesImpl;
import org.springframework.beans.factory.annotation.Autowired;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Random;

public class AccountCreation {

    public void jaxbObjectToXML(Customers customer, long iban) throws JAXBException, IOException, NullPointerException{
        OutputStream outputStream = null;
        try {

            //Create JAXB Context
            JAXBContext jaxbContext = JAXBContext.newInstance(Customers.class);


            //Create Marshaller
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();


            //Required formatting??
            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);


            //Store XML to File


                File file = new File("C:\\Users/sudhasin/Desktop/Payments_Project/K-P/AccountCreationXmlFiles/"+iban+".xml");
            //File masterfile = new File("/Assginments/report/Master.xml");
            if (file.exists()) {

                //Writes XML file to file-system
                jaxbMarshaller.marshal(customer, file);
                //AccjaxbMarshaller.marshal(accounts, masterfile);

            } else {
                outputStream = new FileOutputStream(file);
                jaxbMarshaller.marshal(customer, file);
                //AccjaxbMarshaller.marshal(accounts, file);
                outputStream.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
