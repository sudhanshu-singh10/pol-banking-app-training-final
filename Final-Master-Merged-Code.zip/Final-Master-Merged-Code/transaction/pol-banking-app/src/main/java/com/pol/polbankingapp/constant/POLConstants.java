package com.pol.polbankingapp.constant;

import java.util.Locale;

public class POLConstants {

	public static enum BankName{HDFC,ICICI,KOTAK;
		@Override
		public String toString() {
			return name().toUpperCase();
		}
	};

	public static final String home="user.home";
	public static final String homepath = System.getProperty(home)+"\\POL\\";

	public static enum Bicfi{HDFC0422944,ICICIN33495,KOTAIN44622};
	//public static enum Iban{IN016787654567,AU022343453367,CA036578987678};
	public static enum AccType{ SAVINGS,CURRENT};
	public static enum Currency{INR,EURO,USD};
	public static enum AccStts{ACTIVE,INACTIVE};
	public static final String PAN_VALIDATE ="[A-Z0-9]*$";
	public static final String ADDRESS_VALIDATE="[a-zA-Z0-9 ]*$";
	public static final String BICFI_CODE_VALIDATE="^[A-Z]{4}0[A-Z0-9]{6}$";
	public static final String ALPHA_VALIDATE="[A-Za-z]*$";
	public static final String ALPHA_NUMBERS_VALIDATE="[a-zA-Z0-9]*$";
	public static final String DATE_FORMAT="YYYYMMDD";
	public static final String POST_CODE_VALIDATE="\\d{6}";
	public static final String MOBILE_NUMBER_VALIDATE="\\d{10}";
	public static final String AADHAR_VALIDATE="\\d{12}";
	public static final String SELECT_BANK_MSG="Please Select Appropriate bank!!";
	public static final String PAN_MSG="Please Enter Correct PAN which must contain 10 characters only";
	public static final String PAN_MSG_VALIDATE="Pan must be Alpha Numeric";
	public static final String AADHAR_MSG="Please Enter Correct Aadhar Number having 12 digits";
	public static final String AADHAR_MSG_VALIDATE="Only numbers are allowed!!";
	public static final String DATE_MSG="Please provide Date in YYYY-MM-DD format";
	public static final String FIRSTNAME_MSG="First Name should be atleast 3 characters long";
	public static final String FIRSTNAME_MSG_VALIDATE="It should contains only Alphabet characters";
	public static final String LastNAME_MSG_VALIDATE="It should contains only Alphabet characters";
	public static final String ADDRESS_MSG="Please Provide Sufficient Address";
	public static final String ADDRESS_MSG_VALIDATE="It should Contains only AplhaNumeric characters and Space";
	public static final String CITY_MSG="Please Provide valid City";
	public static final String CITY_MSG_VALIDATE="It should contains only Alphabet characters";
	public static final String STATE_MSG="Please Provide valid State";
	public static final String STATE_MSG_VALIDATE="It should contains only Alphabet characters";
	public static final String COUNTRY_MSG="Please Provide Valid Country";
	public static final String COUNTRY_MSG_VALIDATE="It should contains only Alphabet characters";
	public static final String POSTCODE_MSG="Please Provide valid Postal Code which must contains 6 digits";
	public static final String POSTCODE_MSG_VALIDATE="It should contains Numeric digits only";
	public static final String ACCTYPE_MSG="Select Appropriate Account Type";
	public static final String MOBILE_NUMBER_MSG="Mobile number must contains only 10 numeric digits";
	public static final String MOBILE_NUMBER_MSG_VALIDATE="Characters are not allowed!!";
	public static final String BALANCE_MSG="Opening Balance Must be equal to or more than 1000";
	public static final String EMAIL_MSG = "Please enter a valid e-mail address which should contain @ and .";
	public static final String BICFI_MSG="Please Select Specific BICFI";

	public static final String VALIDATION_FAILED = "Validation Failed";
	public static final String DEBITOR_ACC = "Debitor Account Number should not be Empty!!";
	public static final String DB_BICFI = "Debitor BICFI code should not be Empty!!";
	public static final String CRDT_BICFI = "Creditor BICFI code should not be Empty!!";
	public static final String CREDITOR_ACC = "Creditor Account Number should not be Empty!!";
	public static final String AMOUNT = "Please enter amount >0";
	public static final String AMOUNT_MSG = "!!Amount should greater than Zero!!";
	//  public static final String DATE_FORMAT = "YYYY-MM-DD";
	//  public static final String DATE_MSG = "Date should not be Empty Please provide a date and format should be yyyy-MM-dd";
	public static final String DBACC_VALIDATE = "Account Number allow only letters and numbers";
	public static final String ALPHA_NUMBERS = "^[a-zA-Z0-9]*$";
	public static final String ACCNO_VALIDATION = "!!Acoount Number Should be Minimum 12 and max 16 length allow!!";
	public static final int ACCNO_MIN = 10;
	public static final int ACCNO_MAX = 16;   //first 2 chars and numerics 11totallength
	//public static final String BICFI_CODE_VALIDATE = "^[A-Z]{4}0[A-Z0-9]{6}$";
	public static final String BICFI_MESSAGE = "BICFI code should be 11 characters long,first four characters should be upper case alphabets,fifth character should be 0,  last six characters usually numeric, but can also be alphabetic";
	public static final String TRANSACTION_ID="Transaction Id should contain max length 16 and should start with T";
	public static final String TRANSACTION="EndToEndId should not be null";
	public static final String PAYMENT_NOTE="Not should not be greater than 20 Characters";
	public static final int PAYMENT_CHARS_MAX=20;
	public static final int PAYMENT_CHARS_MIN=0;

}