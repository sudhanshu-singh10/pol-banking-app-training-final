package com.pol.polbankingapp.exception;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import java.sql.Date;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(IncorrectAmountException.class)
    public ResponseEntity<?> resourceNotFoundHandling(IncorrectAmountException exception, WebRequest request){
        String errorDetails = "Debtor account dose not have required balance";
        return new ResponseEntity<>(errorDetails, HttpStatus.FORBIDDEN);
    }

    @ExceptionHandler(IncorrectBicFIException.class)
    public ResponseEntity<?> resourceNotFoundHandling(IncorrectBicFIException exception, WebRequest request){
        String errorDetails = "Creditor BICFI code is wrong , Please check and enter again...!";
        return new ResponseEntity<>(errorDetails, HttpStatus.FORBIDDEN);
    }

    @ExceptionHandler(DebtorNotFoundException.class)
    public ResponseEntity<?> resourceNotFoundHandling(DebtorNotFoundException exception, WebRequest request){
        String errorDetails ="Debtor account dose not exists...!";
                new ErrorDetails(  exception.getMessage());
        return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(CreditorNotFoundException.class)
    public ResponseEntity<?> resourceNotFoundHandling(CreditorNotFoundException exception, WebRequest request){
        String errorDetails ="Creditor account dose not exists...!";
                new ErrorDetails(  exception.getMessage());
        return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(value = {TransactionNotFoundException.class})
    public ResponseEntity<Object> handleException(Exception ex) {
        String errorDetails ="Transaction Info doesn't Exist for this PaymentId";
        return new ResponseEntity<Object>(errorDetails, HttpStatus.NOT_FOUND);

    }
    @ExceptionHandler(IncorrectPaymentMethodException.class)
    public ResponseEntity<?> resourceNotFoundHandling(IncorrectPaymentMethodException exception, WebRequest request){
        String errorDetails ="Payment Method is invalid , it should be IMPS,RTGS,NEFT ";
        new ErrorDetails(  exception.getMessage());
        return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
    }


    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<?> resourceNotFoundHandling(ResourceNotFoundException exception, WebRequest request){
        ErrorDetails errorDetails =
                new ErrorDetails(  exception.getMessage());
        return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<?> globalExceptionHandling(Exception exception, WebRequest request){
        ErrorDetails errorDetails =
                new ErrorDetails( exception.getMessage());
        return new ResponseEntity<>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
    }
    @ExceptionHandler(CreditorAccountInactiveException.class)
    public ResponseEntity<?> globalExceptionHandling(CreditorAccountInactiveException exception, WebRequest request){
        String errorDetails ="Creditor account is Inactive ,Cannot process Transaction...!";
                new ErrorDetails( exception.getMessage());
        return new ResponseEntity<>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
