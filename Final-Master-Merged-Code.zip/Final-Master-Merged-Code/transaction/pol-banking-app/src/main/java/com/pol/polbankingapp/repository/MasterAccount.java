package com.pol.polbankingapp.repository;


import com.pol.polbankingapp.constant.POLConstants;
import com.pol.polbankingapp.model.request.payment.AccountInfo;
import com.pol.polbankingapp.model.request.payment.Accounts;
import com.pol.polbankingapp.model.response.AccountResponse.Customers;
import com.pol.polbankingapp.model.response.AccountResponse.MasterAccounts;
import com.pol.polbankingapp.model.response.payment.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.xml.sax.helpers.DefaultHandler;

import javax.annotation.PostConstruct;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.XmlElement;
import java.io.File;
import java.io.FileInputStream;
@Component
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MasterAccount {

    @Value("${file.directory}")
    private String path;

//    @Autowired
//    MasterAccounts masterMap ;

    //final protected File MASTERFILE = new File(localPath+path+"Master.xml");




//    public Accounts readMasterAccountFile() {
//        JAXBContext jaxbContext;
//        Accounts accounts = null;
//        try (FileInputStream fileInputStream = new FileInputStream(MASTERFILE)) {
//            jaxbContext = JAXBContext.newInstance(Accounts.class);
//            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
//            accounts = (Accounts) unmarshaller.unmarshal(fileInputStream);
//            AccountInfo accountInfo = null;
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return accounts;
//    }

    final private File MASTERFILE = new File(POLConstants.homepath+"Master.xml");

    public MasterAccounts getListofExistingAccount()
    {
        JAXBContext jaxbContext;
        MasterAccounts masterMap=null;
        try (FileInputStream fileInputStream = new FileInputStream(MASTERFILE)) {

            jaxbContext = JAXBContext.newInstance(MasterAccounts.class);
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
            masterMap = (MasterAccounts) jaxbUnmarshaller.unmarshal(fileInputStream);
            System.out.println("Existing Master account" + masterMap);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return masterMap;

    }



   public  Dbtr readAccPersonalDetailsdb(String iban)
    {
        String dirName=POLConstants.homepath+"accounts";
         String strtNm;
         String name;
         String pstCd;
         String twnNm;
         String ctry;
        String debitorIBAN;
        POLConstants.Bicfi bICFI;
        File dir = new File(dirName);
        boolean flag= false;
        File[] dir_Contents = dir.listFiles();
        for(int i=0;i<dir_Contents.length;i++)
        {
            if(dir_Contents[i].getName().equals(iban+".xml"))
            {
                System.out.println("File Present");

                flag=true;
                //return "File Found";
                try {

                    File file = new File(dirName+"/"+iban+".xml");
                    JAXBContext jaxbContext = JAXBContext.newInstance(Customers.class);

                    Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
                    Customers stud= (Customers) jaxbUnmarshaller.unmarshal(file);

                    Dbtr dbtr = null;
                    PstlAdr pstlAdr = null;
                    DbtrAcct dbtrAcct=null;
                    DbtrAgt dbtrAgt;
                    strtNm = stud.getUser().getPstlAdr().getStrtNm();
                    pstCd = stud.getUser().getPstlAdr().getPstCd();
                    twnNm = stud.getUser().getPstlAdr().getTwnNm();
                    ctry = stud.getUser().getPstlAdr().getCtry();
                    name = stud.getUser().getFirst_name()+stud.getUser().getLast_name();
                    debitorIBAN = stud.getAccountinfo().getIban();
                    String dagent = stud.getFinanceInstInfo().getBIcfi();
                    //String debB=dagent.toString();

                    return new Dbtr(name,new PstlAdr(strtNm,pstCd,twnNm,ctry),new DbtrAcct(debitorIBAN,new DbtrAgt(dagent)));


                } catch (JAXBException e) {
                    e.printStackTrace();
                }

            }
            else
            {
                flag=false;
            }
            if(flag)
            {
                break;
            }
            else
            {
                if(i<dir_Contents.length) {
                    continue;
                }
            }


        }
        System.out.println("File not found");
        return null;
    }

    public  Cdtr readAccPersonalDetailscd(String iban)
    {
        String dirName=POLConstants.homepath+"accounts";
        String strtNm;
        String name;
        String pstCd;
        String twnNm;
        String ctry;
        String cIBAN;
        String bICFI;
        File dir = new File(dirName);
        boolean flag= false;
        File[] dir_Contents = dir.listFiles();
        for(int i=0;i<dir_Contents.length;i++)
        {
            if(dir_Contents[i].getName().equals(iban+".xml"))
            {
                System.out.println("File Present");

                flag=true;
                //return "File Found";
                try {

                    File file = new File(dirName+"/"+iban+".xml");
                    JAXBContext jaxbContext = JAXBContext.newInstance(Customers.class);

                    Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
                    Customers stud= (Customers) jaxbUnmarshaller.unmarshal(file);

                    Cdtr dbtr = null;
                    PstlAdr pstlAdr = null;
                    CdtrAcct dbtrAcct=null;
                    CdtrAgt dbtrAgt;
                    strtNm = stud.getUser().getPstlAdr().getStrtNm();
                    pstCd = stud.getUser().getPstlAdr().getPstCd();
                    twnNm = stud.getUser().getPstlAdr().getTwnNm();
                    ctry = stud.getUser().getPstlAdr().getCtry();
                    name = stud.getUser().getFirst_name()+stud.getUser().getLast_name();
                    cIBAN = stud.getAccountinfo().getIban();
                    String cagent = stud.getFinanceInstInfo().getBIcfi();
                    return new Cdtr(name,new PstlAdr(strtNm,pstCd,twnNm,ctry),new CdtrAcct(cIBAN,new CdtrAgt(cagent)));


                } catch (JAXBException e) {
                    e.printStackTrace();
                }

            }
            else
            {
                flag=false;
            }
            if(flag)
            {
                break;
            }
            else
            {
                if(i<dir_Contents.length) {
                    continue;
                }
            }


        }
        System.out.println("File not found");
        return null;
    }


}

