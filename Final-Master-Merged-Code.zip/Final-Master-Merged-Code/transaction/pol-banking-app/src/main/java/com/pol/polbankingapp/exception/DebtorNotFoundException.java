package com.pol.polbankingapp.exception;

public class DebtorNotFoundException extends RuntimeException{

    private static final long serialVersionUID = 1L;
}
