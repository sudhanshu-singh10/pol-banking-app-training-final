package com.pol.polbankingapp.service;

import com.pol.polbankingapp.constant.POLConstants;
import com.pol.polbankingapp.exception.*;
import com.pol.polbankingapp.model.request.AccountCreation.User;
import com.pol.polbankingapp.model.request.PaymentTransfer;
import com.pol.polbankingapp.model.request.payment.AccountInfo;
import com.pol.polbankingapp.model.request.payment.Accounts;
import com.pol.polbankingapp.model.request.payment.Balance;
import com.pol.polbankingapp.model.response.AccountResponse.MasterAccountInfo;
import com.pol.polbankingapp.model.response.AccountResponse.MasterAccounts;
import com.pol.polbankingapp.model.response.payment.*;
import com.pol.polbankingapp.repository.BalanceCSV;
import com.pol.polbankingapp.repository.MasterAccount;
import net.bytebuddy.agent.builder.AgentBuilder;
import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.validation.Valid;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
public class PaymentServiceImpl implements IPaymentService {

    FIToFICstmrCdtTrf fiToFICstmrCdtTrf;
    CdtTrfTxInf cdtTrfTxInf = new CdtTrfTxInf();
    Dbtr dbtr;
    Cdtr cdtr;
    PstlAdr pstlAdr;
    DbtrAcct dbtrAcct;
    DbtrAgt dbtrAgt;
    CdtrAgt cdtrAgt;
    @Autowired
    BalanceCSV balanceCSV;


    @Value("${accounts.local.path}")
    private String path;
    @Value("${balance.local.path}")
    private String balancePath;




    public String intiateTranscation(PaymentTransfer paymentTransfer) throws IOException, JAXBException {

        BalanceCSV balanceCSV = new BalanceCSV();
        BalanceCSV balanceCSV1 = new BalanceCSV();
        FIToFICstmrCdtTrf ob= new FIToFICstmrCdtTrf();

        String debBal;
        String credBal;
        Balance credCsv = new Balance();
        Balance debtCsv = new Balance();

        String credAc,debtAc;
        MasterAccount masterAccount = new MasterAccount();
        MasterAccounts existingmastermap =  masterAccount.getListofExistingAccount();
        System.out.println("Existong master map " + existingmastermap);
        int flag = 0;
        boolean debtor=false;
        boolean creditor=false;
        int dBalance;
        int cBalance;
        boolean dbInactive=false;
        boolean credInactive=false;
        boolean dbalance_less=false;
        boolean wrongbicfi=false;
         String credbicfi ;
         String dbBicfi;
         boolean method=false;

        Map<String, MasterAccountInfo> mapAccountInfo = new HashMap<String, MasterAccountInfo>();
        MasterAccountInfo masterAccountInfo= new MasterAccountInfo();
Accountscheck:
        for (Map.Entry<String, MasterAccountInfo> mapEntry : existingmastermap.getMasterAccountMap().entrySet()) {
            System.out.println("////////");
            if(mapEntry.getKey().equals(paymentTransfer.getDebtoracc())) {
                 flag = 1;
                System.out.println("Inside Debtor check");

               masterAccountInfo=mapEntry.getValue();
               String status=masterAccountInfo.getAccountStatus().toString();
               if(status=="INACTIVE") {
                    dbInactive=true;
                   break Accountscheck;
               }
               if(Integer.parseInt(masterAccountInfo.getInitialBalance())<=paymentTransfer.getAmount())
               {
                   dbalance_less=true;
                   break Accountscheck;
               }
                debtor=true;
                    debtCsv.setTransactionAccountId(paymentTransfer.getDebtoracc());
                    debtCsv.setTransactionAccountId(paymentTransfer.getDebtoracc());
                    debtCsv.setSettlementAmount(String.valueOf(paymentTransfer.getAmount()));
                    debtCsv.setTransactionType("debit");
                    debtCsv.setTransactionDate(LocalDate.now());
                    debtCsv.setStatus("Success");
                    debtCsv.setAccountType(String.valueOf(mapEntry.getValue().getAccountType()));
                    debtCsv.setBalance("");

                    dBalance=Integer.parseInt(masterAccountInfo.getInitialBalance());
                    String updateDb=Integer.toString(dBalance-paymentTransfer.getAmount());
                    dbBicfi=masterAccountInfo.getBicfi().toString();
                    debtAc = paymentTransfer.getDebtoracc();
                    masterAccountInfo.setInitialBalance(updateDb);
                    masterAccountInfo.setBicfi(masterAccountInfo.getBicfi());
                    mapAccountInfo.put(mapEntry.getKey(),masterAccountInfo);

                for (Map.Entry<String, MasterAccountInfo> mapEntry2 : existingmastermap.getMasterAccountMap().entrySet()) {
                    if(mapEntry2.getKey().equals(paymentTransfer.getCreditoracc())){
                             flag = 2;
                        System.out.println("Inside Creditor check");

                        masterAccountInfo = mapEntry2.getValue();
                        String credstatus=masterAccountInfo.getAccountStatus().toString();
                        if(credstatus=="INACTIVE") {
                            credInactive=true;
                            break Accountscheck;
                        }
                         credbicfi=masterAccountInfo.getBicfi();
                        String cbicfi = paymentTransfer.getBicfi();
                        if(paymentTransfer.getMethod().equals("IMPS")||paymentTransfer.getMethod().equals("NEFT")
                                ||paymentTransfer.getMethod().equals("RTGS"))
                        {
                            method=true;
                        }
                        else
                        {
                            throw new IncorrectPaymentMethodException();
                        }
                        if((credbicfi).equals(cbicfi) && method==true)
                        {
                            creditor=true;
                            credCsv.setTransactionAccountId(paymentTransfer.getCreditoracc());
                            credCsv.setSettlementAmount(String.valueOf(paymentTransfer.getAmount()));
                            credCsv.setTransactionType("credit");
                            credCsv.setTransactionDate(LocalDate.now());
                            credCsv.setStatus("Success");
                            credCsv.setAccountType(String.valueOf(mapEntry2.getValue().getAccountType()));
                            credCsv.setBalance("");

                            credAc = paymentTransfer.getCreditoracc();
                            cBalance=Integer.parseInt(masterAccountInfo.getInitialBalance());
                            String updateCr=Integer.toString(cBalance+paymentTransfer.getAmount());
                            masterAccountInfo.setInitialBalance(updateCr);
                            mapAccountInfo.put(mapEntry.getKey(),masterAccountInfo);

                            mapAccountInfo.putAll(existingmastermap.getMasterAccountMap());
                            existingmastermap.setMasterMap(mapAccountInfo);

                            String debtBal=balanceCSV.insertIntoCSV(POLConstants.homepath+"balance\\"+debtAc+".csv",debtCsv);
                            credBal=balanceCSV.insertIntoCSV(POLConstants.homepath+"balance\\"+credAc+".csv",credCsv);



                            try (FileOutputStream outputStream = new FileOutputStream(new File(POLConstants.homepath+"Master.xml"))) {
                                JAXBContext jaxbContext = JAXBContext.newInstance(MasterAccounts.class);
                                Marshaller marshaller = jaxbContext.createMarshaller();
                                marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
                                marshaller.marshal(existingmastermap, outputStream);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                        }
                        else
                        {
                            wrongbicfi=true;
                            break Accountscheck;
                        }
                    }
                        }

                }
            }
        if(debtor==true && creditor==true)
        {
            String dirName=POLConstants.homepath+"payments\\";
            Random rnd = new Random();
            int number = rnd.nextInt(999);

            JAXBContext jaxbContext = JAXBContext.newInstance(FIToFICstmrCdtTrf.class);

            Marshaller jaxbMarshallar = jaxbContext.createMarshaller();
            jaxbMarshallar.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,true);
            String isoDatePattern = "yyyy-MM-dd HH:mm:ss";
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(isoDatePattern);
            String dateString = LocalDateTime.now().toString();

            dateString=dateString.replaceAll("[^a-zA-Z0-9]","");
            String file1 = dateString.toString().replace("T", "");
            file1 = file1.substring(0,12);
            System.out.println(file1);
            String fileName = "T"+file1+number;


            dbtr=masterAccount.readAccPersonalDetailsdb(paymentTransfer.getDebtoracc());
            cdtr=masterAccount.readAccPersonalDetailscd(paymentTransfer.getCreditoracc());
            cdtTrfTxInf.setEndToEndId(fileName);
            cdtTrfTxInf.setClrChanl(paymentTransfer.getMethod());
            cdtTrfTxInf.setAmt(paymentTransfer.getAmount());
            cdtTrfTxInf.setDt(new Date());
            cdtTrfTxInf.setDbtr(dbtr);
            cdtTrfTxInf.setCdtr(cdtr);
            cdtTrfTxInf.setRmtInf(paymentTransfer.getNote());
            cdtTrfTxInf.setTransactionSts("Success");

            ob.setCdtTrfTxInf(cdtTrfTxInf);




            File file = new File(dirName+fileName+".xml");


            jaxbMarshallar.marshal(ob,file);
            jaxbMarshallar.marshal(ob,System.out);

            return "transaction executed";

        }
        if(flag == 0 && dbInactive==false){
            throw new DebtorNotFoundException();
        }
        if (flag == 1 && dbalance_less==false && dbInactive==false){
            throw new CreditorNotFoundException();
        }
        if(dbInactive==true)
        {
            throw new DebitorAccountInactiveException();
        }
        if(flag==2 && credInactive==true)
        {
            throw new CreditorAccountInactiveException();
        }
        if (dbalance_less==true)
        {
            throw new IncorrectAmountException();
        }
        if(wrongbicfi==true)
        {
            throw new IncorrectBicFIException();
        }
        return "transaction executed";
    }

    @Override
    public FIToFICstmrCdtTrf transactionDetailsbyid(String endToEndId) {
        File dir = new File(POLConstants.homepath+"payments\\");
        System.out.println(dir);
        boolean flag= false;
        File[] dir_Contents = dir.listFiles();
        for(int i=0;i<dir_Contents.length;i++)
        {
            if(dir_Contents[i].getName().equals(endToEndId+".xml"))
            {
                System.out.println("File Present");

                flag=true;
                try {

                    File file = new File(POLConstants.homepath+"payments\\"+endToEndId+".xml");
                    JAXBContext jaxbContext = JAXBContext.newInstance(FIToFICstmrCdtTrf.class);

                    Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
                    FIToFICstmrCdtTrf stud= (FIToFICstmrCdtTrf) jaxbUnmarshaller.unmarshal(file);
                    return  stud;

                } catch (Exception e) {
                    throw new TransactionNotFoundException();
                }

            }
            else
            {
                flag=false;
            }
            if(flag)
            {
                break;
            }
            else
            {
                if(i<dir_Contents.length) {
                    continue;
                }
            }


        }
        throw new TransactionNotFoundException();
    }


    // Implementation for GET PAYMENTS by PAYMENT_ID

//    @Override
//    public  FIToFICstmrCdtTrf transactionDetailsbyid(String endToEndId) throws TransactionNotFoundException {
//
//          //return null;
//    }




    public TranscationDetailsBetweenDates getTransctaionDetailsBetweenDates(String accountid,String fromDate,String toDate) throws Exception {
        TranscationDetailsBetweenDates details=   balanceCSV.insertIntoCSV(POLConstants.homepath+"balance//",accountid,fromDate,toDate);
        return  details;
    }
}