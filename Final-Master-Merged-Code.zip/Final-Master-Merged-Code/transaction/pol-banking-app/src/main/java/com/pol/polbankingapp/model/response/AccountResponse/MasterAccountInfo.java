package com.pol.polbankingapp.model.response.AccountResponse;

import com.pol.polbankingapp.constant.POLConstants;
import com.pol.polbankingapp.repository.MasterAccount;
import com.pol.polbankingapp.service.UserServicesImpl;
import lombok.Data;

import javax.xml.bind.annotation.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@XmlRootElement(name="AccountInfo")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlSeeAlso({MasterAccount.class, UserServicesImpl.class})
@Data
public class MasterAccountInfo {

    @XmlElement(name = "Customer_id")
    private int customer_id;
    @XmlElement(name = "AccountType")
    private POLConstants.AccType accountType;
    @XmlElement(name = "Cuurency")
    private POLConstants.Currency cuurency;
    @XmlElement(name = "AccountStatus")
    private POLConstants.AccStts accountStatus;
    @XmlElement(name = "InitialBalance")
    private String initialBalance;
    @XmlElement(name = "BICFI")
    private String bicfi;
    @XmlElement(name = "CreDtTm")
    private String creDtTm;

    @XmlAttribute(name = "IBAN")
    private String iban;
    @XmlAttribute (name = "Panid")
    private String panid;




}