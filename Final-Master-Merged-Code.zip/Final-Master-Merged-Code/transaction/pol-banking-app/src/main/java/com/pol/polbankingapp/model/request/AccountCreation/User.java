package com.pol.polbankingapp.model.request.AccountCreation;

import java.time.LocalDate;
import javax.validation.constraints.*;

import org.springframework.format.annotation.DateTimeFormat;

import com.pol.polbankingapp.model.response.AccountResponse.AccountInfo;
import com.pol.polbankingapp.constant.POLConstants;
import com.pol.polbankingapp.constant.POLConstants.AccType;
import com.pol.polbankingapp.constant.POLConstants.BankName;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class User extends AccountInfo{

	@NotEmpty(message = POLConstants.FIRSTNAME_MSG)
	@Pattern(regexp = POLConstants.ALPHA_VALIDATE,message = POLConstants.FIRSTNAME_MSG_VALIDATE)
	private String firstName;
	
	@NotEmpty
	@Pattern(regexp = POLConstants.ALPHA_VALIDATE,message = POLConstants.LastNAME_MSG_VALIDATE)
	private String lastName;
	
    @NotEmpty(message = POLConstants.AADHAR_MSG)
	@Pattern(regexp = POLConstants.AADHAR_VALIDATE, message = POLConstants.AADHAR_MSG_VALIDATE)
    @Size(min = 12, max = 12, message = POLConstants.AADHAR_MSG)
	private String aadhar;
	
	@DateTimeFormat(pattern = POLConstants.DATE_FORMAT)
	@NotNull(message = POLConstants.DATE_MSG)
	private LocalDate dob;
	
	@NotEmpty(message = POLConstants.PAN_MSG)
	@Pattern(regexp = POLConstants.PAN_VALIDATE, message = POLConstants.PAN_MSG_VALIDATE)
	@Size(min =10 ,max = 10, message = POLConstants.PAN_MSG)
	private String pan;
	
 	@NotNull(message = POLConstants.MOBILE_NUMBER_MSG)
	@Pattern(regexp = POLConstants.MOBILE_NUMBER_VALIDATE,message = POLConstants.MOBILE_NUMBER_MSG_VALIDATE)
	@Size(min = 10, max=10, message = POLConstants.MOBILE_NUMBER_MSG)
	private String mobileNumber;
	
	@NotEmpty(message = POLConstants.EMAIL_MSG)
	@Email
	private String email;
	
	@NotEmpty(message = POLConstants.ADDRESS_MSG)
	@Pattern(regexp = POLConstants.ADDRESS_VALIDATE,message = POLConstants.ADDRESS_MSG_VALIDATE)
	private String streetName;

	@NotEmpty(message = POLConstants.POSTCODE_MSG)
	@Pattern(regexp = POLConstants.POST_CODE_VALIDATE,message = POLConstants.POSTCODE_MSG_VALIDATE)
	@Size(min =6, max=6, message = POLConstants.POSTCODE_MSG)
	private String postCode;
	
	@NotEmpty(message = POLConstants.CITY_MSG)
	@Pattern(regexp = POLConstants.ALPHA_VALIDATE,message = POLConstants.CITY_MSG_VALIDATE)
	@Size(max = 15)
	private String city;
	
	@NotEmpty(message = POLConstants.STATE_MSG)
	@Pattern(regexp = POLConstants.ALPHA_VALIDATE,message = POLConstants.STATE_MSG_VALIDATE)
	private String state;
	
	@NotEmpty(message = POLConstants.COUNTRY_MSG)
	@Pattern(regexp = POLConstants.ALPHA_VALIDATE,message = POLConstants.COUNTRY_MSG_VALIDATE)
	private String country;
	
	@NotNull
	@Min(value = 1000, message = POLConstants.BALANCE_MSG)
	private int openingBalance;

	@NotNull(message = POLConstants.ACCTYPE_MSG)
	private String accType;

	@NotNull (message = POLConstants.SELECT_BANK_MSG)
	//@NotBlank(message = POLConstants.SELECT_BANK_MSG)
	private String bankName ;

	//@NotNull (message = POLConstants.BICFI_MSG)
	//@NotBlank(message = POLConstants.BICFI_MSG)
	private POLConstants.Bicfi bicfi;
	
}
