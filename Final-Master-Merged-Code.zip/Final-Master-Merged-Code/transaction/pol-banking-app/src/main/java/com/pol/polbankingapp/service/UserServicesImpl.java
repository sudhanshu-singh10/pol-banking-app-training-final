package com.pol.polbankingapp.service;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Random;
import com.pol.polbankingapp.constant.POLConstants;
import com.pol.polbankingapp.exception.ResourceNotFoundException;
import com.pol.polbankingapp.model.request.AccountCreation.AddressInfo;
import com.pol.polbankingapp.model.request.AccountCreation.FinanceInstInfo;
import com.pol.polbankingapp.model.request.AccountCreation.UserInfo;
import com.pol.polbankingapp.model.response.AccountResponse.AccountInfo;
import com.pol.polbankingapp.model.response.AccountResponse.Customers;
import com.pol.polbankingapp.repository.AccountCreation;
import org.springframework.stereotype.Service;

import com.pol.polbankingapp.model.request.AccountCreation.User;

import javax.xml.bind.JAXBException;

@Service
public class UserServicesImpl implements com.pol.polbankingapp.service.UserServices {

    public long Iban;

    public Object createAccount(User userrequest) throws JAXBException, IOException {

        AccountCreation accountCreation = new AccountCreation();

        Customers customer = new Customers();
        UserInfo userInfo = new UserInfo();
        AccountInfo accountinfo = new AccountInfo();
        FinanceInstInfo financeInstInfo = new FinanceInstInfo();
        AddressInfo addres = new AddressInfo();
        //Accounts accounts = new Accounts();


        userInfo.setFirst_name(userrequest.getFirstName());
        userInfo.setLast_name(userrequest.getLastName());
        userInfo.setDob(userrequest.getDob().toString());
        userInfo.setEmail(userrequest.getEmail());
        userInfo.setAadhar(userrequest.getAadhar());
        userInfo.setMobile(userrequest.getMobileNumber());
        userInfo.setPanid(userrequest.getPan());


        addres.setCtry(userrequest.getCountry());
        addres.setPstCd(userrequest.getPostCode());
        addres.setStrtNm(userrequest.getStreetName());
        addres.setTwnNm(userrequest.getCity());
        String Bank= userrequest.getBankName().toUpperCase();
        
        financeInstInfo.setBank_name(Bank);

        if(Bank.equals("HDFC")){
            financeInstInfo.setBicfi((POLConstants.Bicfi.HDFC0422944).toString());
        } else if (Bank.equals("ICICI")){
            financeInstInfo.setBicfi((POLConstants.Bicfi.ICICIN33495).toString());
        } else if (Bank.equals("KOTAK")){
            financeInstInfo.setBicfi((POLConstants.Bicfi.KOTAIN44622).toString());
        } else {
        	throw new ResourceNotFoundException("Please select appropriate bank!");
        }

        String accountType = userrequest.getAccType().toUpperCase();
        
        if(accountType.equals("SAVINGS")) {
        	accountinfo.setAccountType(accountType);
        } else if(accountType.equals("CURRENT")) {
        	accountinfo.setAccountType(accountType);
        }else {
        	throw new ResourceNotFoundException("Please select valid Account Type!");
        }
        	
        String currency = userrequest.getCurrency().toUpperCase();
        if(currency.equals("INR")) {
        	accountinfo.setCurrency(currency);
        } else if(currency.equals("EURO")) {
        	accountinfo.setCurrency(currency);
        } else if(currency.equals("USD")) {
        	accountinfo.setCurrency(currency);
        } else {
        	throw new ResourceNotFoundException("Please Select Valid Currency!");
        }
        
        
        
        accountinfo.setInitialBalance(String.valueOf(userrequest.getOpeningBalance()));
        accountinfo.setAccountStatus(POLConstants.AccStts.ACTIVE);
        accountinfo.setCreDtTm(LocalDateTime.now().withNano(0).toString());
        accountinfo.setIban(String.valueOf(createIBAN()));
        //accountinfo.setIban(accountCreation.getIBAN());

        customer.setUser(userInfo);
        customer.setAccountinfo(accountinfo);
        customer.setFinanceInstInfo(financeInstInfo);
        userInfo.setPstlAdr(addres);
        userInfo.setCustomer_id(getCustomerID());

        accountCreation.jaxbObjectToXML(customer, Iban);

        return accountCreation;
    }

    public long createIBAN() {

        Random rnd = new Random();
        long IBAN = rnd.nextInt(1_000_000_000)               // Last 9 digits
                + (rnd.nextInt(50) + 10) * 1_000_000_000L;      // First 2 digits
        this.Iban = IBAN;
        //setIban(String.valueOf(IBAN));
        return IBAN;
    }

    public int getCustomerID(){
        int customID =  (100000 + new Random().nextInt(90000));
        return customID;
    }

}
