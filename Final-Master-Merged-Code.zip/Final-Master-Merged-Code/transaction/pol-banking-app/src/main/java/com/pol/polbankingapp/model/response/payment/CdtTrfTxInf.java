package com.pol.polbankingapp.model.response.payment;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@XmlRootElement(name = "CdtTrfTxInf")
@XmlAccessorType(XmlAccessType.FIELD)
public class CdtTrfTxInf {
    @XmlElement(name="EndToEndId")
    private String endToEndId;
    @XmlElement(name="ClrChanl")
    private String clrChanl;
    @XmlElement(name="Amt")
    private int amt;
    @XmlElement(name="Dt")
    private Date dt;
    @XmlElement(name="Dbtr")
    private Dbtr dbtr;
    @XmlElement(name="Cdtr")
    private Cdtr cdtr;
    @XmlElement(name="RmtInf")
    private String rmtInf;
    @XmlElement(name="TransactionSts")
    private String transactionSts;


}
