package com.pol.polbankingapp.controller;

import com.pol.polbankingapp.constant.POLConstants;
import com.pol.polbankingapp.model.request.PaymentTransfer;
import com.pol.polbankingapp.model.response.payment.FIToFICstmrCdtTrf;
import com.pol.polbankingapp.model.response.payment.TranscationDetailsBetweenDates;
import com.pol.polbankingapp.model.response.payment.TranscationResponse;
import com.pol.polbankingapp.service.IPaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.xml.bind.JAXBException;
import java.io.IOException;

@Validated
@RestController
@RequestMapping("/payments")
public class PaymentController {
    @Autowired
    private IPaymentService paymentService;
    @RequestMapping(value = "/transction", method = RequestMethod.POST, produces = {"application/xml", "text/xml", "application/json"}, consumes = {"application/xml", "text/xml", "application/json"})
    @ResponseBody
    public String intiatePaymentTranscation( @Valid @RequestBody PaymentTransfer paymentTransfer) throws IOException, JAXBException {

        paymentService.intiateTranscation(paymentTransfer);
        return "Transaction Executed...!";
    }


    //GET PAYMENTS BY PAYMENT_ID

    @RequestMapping(value="/{endToEndId}", method = RequestMethod.GET, produces = {"application/json"},consumes = {"application/xml", "text/xml", "application/json"})
    public FIToFICstmrCdtTrf transactionDetails(@Valid @PathVariable("endToEndId")  @Size(min=16,max=16,message = "Should contain min 16 and max 16") @Pattern(regexp = POLConstants.ALPHA_NUMBERS, message = "TransactionId should not contain special characters") String endToEndId )throws Exception
    {
        FIToFICstmrCdtTrf tr= paymentService.transactionDetailsbyid(endToEndId);
        return tr;
    }
    @GetMapping(value = "/{accountid}/Date")
    public ResponseEntity<Object> responseMsg( @PathVariable String accountid ,@RequestParam("fromDate") String fromDate, @RequestParam("toDate") String toDate) throws Exception {
        TranscationDetailsBetweenDates detailsBetweenDates= paymentService.getTransctaionDetailsBetweenDates(accountid,fromDate,toDate);
        return new ResponseEntity<>(detailsBetweenDates, HttpStatus.OK);
    }

}
