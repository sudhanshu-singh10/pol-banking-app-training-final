package com.pol.polbankingapp.repository;


import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.pol.polbankingapp.model.request.payment.Balance;
import com.pol.polbankingapp.model.response.AccountResponse.MasterAccountInfo;
import com.pol.polbankingapp.model.response.AccountResponse.MasterAccounts;
import com.pol.polbankingapp.model.response.payment.TranscationDetailsBetweenDates;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.validation.constraints.Null;
import java.io.*;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Component
public class BalanceCSV {

    public String insertIntoCSV(String filename, Balance balObj) throws IOException {

        String[] obj = BalanceCSV.toStringArray(balObj);
        String updatedBalance="";

        try(BufferedReader br = new BufferedReader(new FileReader(filename))){

            String lastLine = "";
            String line = "";

            while ((line = br.readLine()) != null) {
                lastLine = line;
            }
            System.out.println(lastLine);

            String[] str = lastLine.split(",");
            System.out.println(str);
            System.out.println(str[4]);
            int value= Integer.parseInt(str[4].substring(1,str[4].length()-1));
//            Integer value = Integer.valueOf(dummy).intValue();
            System.out.println(value);

            try{
                if(balObj.getTransactionType().equalsIgnoreCase("credit")){
                    try{
                        updatedBalance = String.valueOf(value + Integer.parseInt(balObj.getSettlementAmount()));
                    }catch (NumberFormatException nfe){
                        nfe.printStackTrace();
                    }
                }
                else
                    try{
                        updatedBalance = String.valueOf(value - Integer.parseInt(balObj.getSettlementAmount()));
                    }catch (NumberFormatException nfe){
                        nfe.printStackTrace();
                    }
                obj[4] = updatedBalance;
            }catch (Exception e){
                e.printStackTrace();
            }
        }




        CSVReader reader = null;

        try {

            try {
                reader = new CSVReader(new FileReader(filename));
            } catch (FileNotFoundException fileNotFoundException) {
                fileNotFoundException.printStackTrace();
            }

            CSVWriter writer = new CSVWriter(new FileWriter(filename,true));
            writer.flush();
            //Writing data to a csv file


            writer.writeNext(obj);
            writer.flush();
        } finally {
            String newBalance = getLastUpdatedBalance(filename);
            System.out.println(updatedBalance);
            return newBalance;

        }

    }

    public static String getLastUpdatedBalance(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String lastLine = "";
            String line = "";
            String[] strexample = new String[6];
            while ((line = br.readLine()) != null) {
                lastLine = line;
                strexample = lastLine.split(",");
            }
            String bal = strexample[4].substring(1, strexample[4].length() - 1);
            return bal;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
    public static String[] toStringArray(Balance balObj){

        String[] obj = new String[7];
        obj[0] = balObj.getTransactionAccountId();
        obj[1] = balObj.getSettlementAmount();
        obj[2] = balObj.getTransactionType();

        //Format formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate dt = LocalDate.now();
        //obj[3] = formatter.format(dt);
        obj[3] = dt.format(formatter);

        obj[4] = balObj.getBalance();
        obj[5] = balObj.getStatus();
        obj[6] = balObj.getAccountType();

        return  obj;

    }

//    @Value("${file.location}")
//    static String dirName;

    public static String findFile(String file) {

        String home="user.home";
        String homepath = System.getProperty(home)+"\\POL\\";

            File directory = new File(homepath+"accounts\\");




        // Create an object of Class MyFilenameFilter
        // Constructor with name of file which is being
        // searched
        MyFilenameFilter filter
                = new MyFilenameFilter(file);

        // store all names with same name
        // with/without extension
        String[] flist = directory.list(filter);

        // Empty array
        if (flist == null) {
            System.out.println(
                    "Empty directory or directory does not exists.");
        } else {
            System.out.println(flist[0]);
            return null;
        }

        return null;

    }

    static class MyFilenameFilter implements FilenameFilter {



        String initials;

        // constructor to initialize object
        public MyFilenameFilter(String initials)
        {
            this.initials = initials;
        }

        // overriding the accept method of FilenameFilter
        // interface
        public boolean accept(File dir, String name)
        {
            return name.startsWith(initials);
        }
    }



    void updateMasterXML(String debt,String Cred)
    {
        MasterAccount masterAccount = new MasterAccount();
        MasterAccounts existingmastermap =  masterAccount.getListofExistingAccount();
        System.out.println("Existong master map " + existingmastermap);
        int flag = 0;
        boolean debtor=false;
        boolean creditor=false;
        int debitorSendingBalance = 0;
        int debitorCurrentBalance = 0;
        Map<String, MasterAccountInfo> mapAccountInfo = new HashMap<String, MasterAccountInfo>();
        MasterAccountInfo masterAccountInfo= new MasterAccountInfo();



    }

    public TranscationDetailsBetweenDates insertIntoCSV(String filename,String accountid, String fromDate, String toDate) throws Exception {
        String line = "";
        String splitBy = ",";
        TranscationDetailsBetweenDates transcationDetailsBetweenDates = null;
        try {
            BufferedReader br = new BufferedReader(new FileReader(filename +accountid+".csv"));
            List<Balance> listData = new ArrayList<Balance>();
            Balance balance = null;
            int i = 0;
            while ((line = br.readLine()) != null) {
                i++;
                if (i == 1) {
                    continue;
                } else {
                    String[] data = line.split(splitBy);
                    balance = new Balance();
                    String tan = data[0];
                    String transcationID = tan.substring(1, tan.length() - 1);
                    balance.setTransactionAccountId(transcationID);
                    String st = data[1];
                    String status = st.substring(1, st.length() - 1);
                    balance.setSettlementAmount(status);
                    String tarntype = data[2];
                    String tarnType = tarntype.substring(1, tarntype.length() - 1);
                    balance.setTransactionType(tarnType);
                    String date = data[3];
                    String dd = date.substring(1, date.length() - 1);
                    LocalDate date1 = LocalDate.parse(dd);
                    LocalDate alDate = date1;
                    balance.setTransactionDate(alDate);
                    String bal = data[4];
                    String balanc = bal.substring(1, bal.length() - 1);
                    balance.setBalance(balanc);
                    String sta = data[5];
                    String statuss = sta.substring(1, sta.length() - 1);
                    balance.setStatus(statuss);
                    String acctyp = data[6];
                    String acctype = acctyp.substring(1, acctyp.length() - 1);
                    balance.setAccountType(acctype);
                    listData.add(balance);
                }
            }
            LocalDate date1 = LocalDate.parse(fromDate);
            LocalDate fDate = date1;
            LocalDate date2 = LocalDate.parse(toDate);
            LocalDate tDate = date2;

            List<Balance> responseData = listData.stream().filter(balance1 -> balance1.getTransactionDate().isAfter(fDate) && balance1.getTransactionDate().isBefore(tDate) || balance1.getTransactionDate().isEqual(fDate) || balance1.getTransactionDate().isEqual(tDate)).collect(Collectors.toList());
            transcationDetailsBetweenDates = new TranscationDetailsBetweenDates();
            transcationDetailsBetweenDates.setTranscationsDetails(responseData);

        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(transcationDetailsBetweenDates);
        return transcationDetailsBetweenDates;
    }

}


