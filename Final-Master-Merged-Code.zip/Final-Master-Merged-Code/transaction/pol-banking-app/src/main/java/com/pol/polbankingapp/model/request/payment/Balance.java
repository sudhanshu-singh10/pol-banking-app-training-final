package com.pol.polbankingapp.model.request.payment;

import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Balance {
    private String transactionAccountId;
    private String settlementAmount;
    private String transactionType;
    private LocalDate transactionDate;
    private String balance;
    private String status;
    private String accountType;
}

