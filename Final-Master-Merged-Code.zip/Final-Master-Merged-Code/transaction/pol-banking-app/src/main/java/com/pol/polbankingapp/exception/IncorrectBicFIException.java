package com.pol.polbankingapp.exception;

public class IncorrectBicFIException extends RuntimeException{
    private static final long serialVersionUID = 1L;
}