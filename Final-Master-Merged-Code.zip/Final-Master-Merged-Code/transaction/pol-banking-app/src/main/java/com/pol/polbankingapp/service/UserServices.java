package com.pol.polbankingapp.service;

import com.pol.polbankingapp.model.request.AccountCreation.User;

import javax.xml.bind.JAXBException;
import java.io.IOException;

public interface UserServices {

    public Object createAccount(User userrequest) throws JAXBException, IOException;

}
