# pol-banking-app
POL-Payment Orchestration Layer deals with orchestration of payment process for HSBC payment system. This repository is created for mock banking assignment dealing with account and transaction management.
