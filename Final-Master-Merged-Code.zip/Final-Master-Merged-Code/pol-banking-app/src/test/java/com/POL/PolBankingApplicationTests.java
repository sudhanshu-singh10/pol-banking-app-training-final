package com.pol;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PolBankingApplicationTests {

	@Test
	void contextLoads() {
	}

}
