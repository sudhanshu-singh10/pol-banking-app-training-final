package com.POL.polbankingapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PolBankingApplicationTests {

	@Test
	void contextLoads() {
	}

}
