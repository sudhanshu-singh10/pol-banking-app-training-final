package com.pol.polbankingapp.model.request.AccountCreation;

import com.pol.polbankingapp.constant.POLConstants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AccountUpdate {

//    @NotEmpty(message = POLConstants.BankName)
//    private String bicfi;

    @NotEmpty(message = POLConstants.PAN_MSG)
    @Pattern(regexp = POLConstants.PAN_VALIDATE, message = POLConstants.PAN_MSG_VALIDATE)
    @Size(min = 10, max = 10, message = POLConstants.PAN_MSG)
    private String pan;


    @NotNull(message = POLConstants.IBAN_MSG)
    @Pattern(regexp = POLConstants.IBAN_VALIDATE, message = POLConstants.IBAN_MSG_VALIDATE)
    @Size(min = 11, max = 11, message = POLConstants.IBAN_MSG)
    @Min(value = 11, message = POLConstants.IBAN_MSG)
    private String iban;

//    @NotEmpty(message = POLConstants.ADDRESS_MSG)
//    @Pattern(regexp = POLConstants.ADDRESS_VALIDATE, message = POLConstants.ADDRESS_MSG_VALIDATE)
//    private String bldgNb;

    @NotEmpty(message = POLConstants.ADDRESS_MSG)
    @Pattern(regexp = POLConstants.ADDRESS_VALIDATE, message = POLConstants.ADDRESS_MSG_VALIDATE)
    private String streetName;

//    @NotEmpty(message = POLConstants.STATE_MSG)
//    @Pattern(regexp = POLConstants.ALPHA_VALIDATE, message = POLConstants.STATE_MSG_VALIDATE)
//    private String state;

    @NotEmpty(message = POLConstants.CITY_MSG)
    @Pattern(regexp = POLConstants.ALPHA_VALIDATE, message = POLConstants.CITY_MSG_VALIDATE)
    @Size(max = 15)
    private String city;

    @NotEmpty(message = POLConstants.POSTCODE_MSG)
    @Pattern(regexp = POLConstants.POST_CODE_VALIDATE, message = POLConstants.POSTCODE_MSG_VALIDATE)
    @Size(min = 6, max = 6, message = POLConstants.POSTCODE_MSG)
    private String postCode;

    @NotNull(message = POLConstants.MOBILE_NUMBER_MSG)
    @Pattern(regexp = POLConstants.MOBILE_NUMBER_VALIDATE, message = POLConstants.MOBILE_NUMBER_MSG_VALIDATE)
    @Size(min = 10, max = 10, message = POLConstants.MOBILE_NUMBER_MSG)
    @Min(value = 10, message = POLConstants.MOBILE_NUMBER_MSG)
    private String mobileNumber;

}
