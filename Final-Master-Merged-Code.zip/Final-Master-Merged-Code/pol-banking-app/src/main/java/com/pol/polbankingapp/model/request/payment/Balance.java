package com.pol.polbankingapp.model.request.payment;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Balance {

    private String transactionAccountId;
    private String settlementAmount;
    private String transactionType;
    private Date transactionDate;
    private String balance;
    private String status;
    private String accountType;
}
