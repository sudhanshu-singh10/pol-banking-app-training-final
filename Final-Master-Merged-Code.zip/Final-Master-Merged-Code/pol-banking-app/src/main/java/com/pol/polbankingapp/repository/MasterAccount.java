package com.pol.polbankingapp.repository;

import com.pol.polbankingapp.model.request.payment.AccountInfo;
import com.pol.polbankingapp.model.request.payment.Accounts;
import com.pol.polbankingapp.model.response.AccountResponse.MasterAccounts;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.*;

@Component
public class MasterAccount{

    @Value("#{systemProperties['user.home']}")
    private String localPath;
    @Value("${local.path}")
    private String path;

    public Accounts readMasterAccountFile() {
        JAXBContext jaxbContext;
        Accounts accounts = null;

        try (FileInputStream fileInputStream = new FileInputStream(new File(localPath+path+"Master.xml"))) {
            jaxbContext = JAXBContext.newInstance(Accounts.class);
            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
            accounts = (Accounts) unmarshaller.unmarshal(fileInputStream);
            AccountInfo accountInfo = null;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return accounts;
    }

    public MasterAccounts getListofExistingAccount() throws JAXBException
    {
        JAXBContext jaxbContext;
        MasterAccounts masterMap = null;
        try (FileInputStream fileInputStream = new FileInputStream(new File(localPath+path+"Master.xml"))) {
            jaxbContext = JAXBContext.newInstance(MasterAccounts.class);
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
            masterMap = (MasterAccounts) jaxbUnmarshaller.unmarshal(fileInputStream);
            System.out.println("Existing Master account" + masterMap);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return masterMap;
    }

    public int getrequestedibanbalance(String iban){


        return 100;
    }

    public void MasterjaxbObjectToXML(MasterAccounts mas) throws JAXBException, IOException, NullPointerException{
        OutputStream outputStream = null;
        try {

            //Create JAXB Context
            JAXBContext masterjaxbContext = JAXBContext.newInstance(MasterAccounts.class);

            //Create Marshaller
            Marshaller masterjaxbMarshaller = masterjaxbContext.createMarshaller();

            //Required formatting??
            masterjaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

            //Store XML to File
            File masterfile = new File(localPath+path+"Master.xml");
            if (masterfile.exists()) {
                //Writes XML file to file-system
                masterjaxbMarshaller.marshal(mas, masterfile);

            } else {
                outputStream = new FileOutputStream(masterfile);
                masterjaxbMarshaller.marshal(mas, masterfile);

                outputStream.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}

