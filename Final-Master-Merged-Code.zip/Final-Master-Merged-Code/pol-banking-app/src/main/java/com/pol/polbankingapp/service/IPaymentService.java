package com.pol.polbankingapp.service;

import com.pol.polbankingapp.model.request.payment.PaymentTransfer;
import com.pol.polbankingapp.model.response.payment.FIToFICstmrCdtTrf;

import javax.xml.bind.JAXBException;

public interface IPaymentService {
   public String intiateTranscation(PaymentTransfer paymentTransfer);
   public FIToFICstmrCdtTrf transactionDetailsbyid(long endToEndId);
   public  FIToFICstmrCdtTrf transactionFileGeneration(FIToFICstmrCdtTrf ob) throws JAXBException;

}