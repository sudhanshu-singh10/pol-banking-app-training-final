package com.pol.polbankingapp.model.response.AccountResponse;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.pol.polbankingapp.constant.POLConstants;
import com.pol.polbankingapp.constant.POLConstants.AccStts;
import com.pol.polbankingapp.constant.POLConstants.Bicfi;
import com.pol.polbankingapp.constant.POLConstants.Currency;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="AccountInfo")
@Data
@NoArgsConstructor
@AllArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
public class AccountInfo {

//	private int custId;
//	private Currency currency;
//	private AccStts accStts;
//	private LocalDateTime accTimeStamp;
	//private Bicfi bicfi;
	//private Iban iban;


	@XmlElement(name = "AccountType")
	private POLConstants.AccType accountType;
	@XmlElement(name = "Cuurency")
	private Currency cuurency;
	@XmlElement(name = "AccountStatus")
	private AccStts accountStatus;
	@XmlElement(name = "InitialBalance")
	private String initialBalance;
	@XmlElement(name = "IBAN")
	private String iban;
	@XmlElement(name = "CreDtTm")
	private String creDtTm;
}
