package com.pol.polbankingapp.service;

import com.pol.polbankingapp.model.response.AccountResponse.MasterAccountInfo;

import javax.xml.bind.annotation.adapters.XmlAdapter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MapAdapter extends XmlAdapter<MapAdapter.AdaptedMap, Map<String, MasterAccountInfo>> {
static  MasterAccountInfo masterAccountInfo = new MasterAccountInfo();
    public static class AdaptedMap {

        public List<Entry> entry = new ArrayList<Entry>();

    }

    public static class Entry {

        public String key;//IBAN

        public void getKey() {
            this.key = masterAccountInfo.getIban();;
        }

        public MasterAccountInfo value;

    }

    @Override
    public Map<String, MasterAccountInfo> unmarshal(AdaptedMap adaptedMap) throws Exception {
        Map<String, MasterAccountInfo> map = new HashMap<>();
        for(Entry entry: adaptedMap.entry){
            map.put(entry.key, entry.value);
        }

        return map;
    }

    @Override
    public AdaptedMap marshal(Map<String, MasterAccountInfo> map) throws Exception {
        AdaptedMap adaptedMap = new AdaptedMap();
        for(Map.Entry<String, MasterAccountInfo> mapEntry: map.entrySet()){

            Entry entry = new Entry();
            entry.key = mapEntry.getKey();
            entry.value = mapEntry.getValue();
            adaptedMap.entry.add(entry);
        }
        return adaptedMap;
    }




//    @Override
//    public Map<String, Address> unmarshal(AdaptedMap adaptedMap) throws Exception {
//        Map<String, Address> map = new HashMap<String, Address>();
//        for(Entry entry : adaptedMap.entry) {
//            map.put(entry.key, entry.value);
//        }
//        return map;
//    }
//
//    @Override
//    public AdaptedMap marshal(Map<String, Address> map) throws Exception {
//        AdaptedMap adaptedMap = new AdaptedMap();
//        for(Map.Entry<String, Address> mapEntry : map.entrySet()) {
//            Entry entry = new Entry();
//            entry.key = mapEntry.getKey();
//            entry.value = mapEntry.getValue();
//            adaptedMap.entry.add(entry);
//        }
//        return adaptedMap;
//    }
}
