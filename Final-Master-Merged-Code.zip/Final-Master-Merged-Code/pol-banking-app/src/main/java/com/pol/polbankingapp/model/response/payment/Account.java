package com.pol.polbankingapp.model.response.payment;

public class Account {

}
