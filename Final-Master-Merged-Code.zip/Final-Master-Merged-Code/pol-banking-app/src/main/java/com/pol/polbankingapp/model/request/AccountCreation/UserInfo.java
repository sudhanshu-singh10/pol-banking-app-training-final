package com.pol.polbankingapp.model.request.AccountCreation;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.time.LocalDate;
import java.util.Date;
@XmlRootElement(name = "UserInfo")
//@XmlType(propOrder = {
//        "first_name",
//        "last_name",
//        "dob",
//        "panid",
//        "aadhar",
//        "mobile",
//        "email",
//        "pstlAdr"
//})
@XmlAccessorType(XmlAccessType.FIELD)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserInfo {

    @XmlElement(name = "Customer_id")
    private int customer_id;
    @XmlElement(name = "First_name")
    private String first_name;
    @XmlElement(name = "Last_name")
    private String last_name;
    @XmlElement(name = "Dob")
    private String dob;
    @XmlElement(name = "Panid")
    private String panid;
    @XmlElement(name = "Aadhar")
    private String aadhar;
    @XmlElement(name = "email")
    private String email;
    @XmlElement(name = "Mobile")
    private String mobile;
    @XmlElement(name = "PstlAdr")
    private AddressInfo PstlAdr;
}
