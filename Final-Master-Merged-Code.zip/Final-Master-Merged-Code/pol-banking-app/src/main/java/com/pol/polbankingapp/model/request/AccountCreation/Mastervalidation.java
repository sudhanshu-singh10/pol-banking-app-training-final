package com.pol.polbankingapp.model.request.AccountCreation;

import com.pol.polbankingapp.constant.POLConstants;
import lombok.Data;

@Data
public class Mastervalidation {

    private POLConstants.AccType accType;
    private POLConstants.Bicfi bicfi;
    private POLConstants.AccStts accountStatus;


    public Mastervalidation(POLConstants.AccType accountType, POLConstants.Bicfi bicfi, POLConstants.AccStts accountStatus) {
        this.accType =accountType;
        this.bicfi =bicfi;
        this.accountStatus = accountStatus;
    }
}
