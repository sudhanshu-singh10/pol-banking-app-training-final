package com.pol.polbankingapp.model.request.AccountCreation;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="PstlAdr")
//@XmlType(propOrder = {
//        "StrtNm",
//        "BldgNb",
//        "PstCd",
//        "TwnNm",
//        "Ctry"
//})
@XmlAccessorType(XmlAccessType.FIELD)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AddressInfo {
    @XmlElement(name ="StrtNm" )
    private String strtNm;
//    @XmlElement(name ="BldgNb" )
//    private String bldgNb;
    @XmlElement(name ="PstCd" )
    private String pstCd;
    @XmlElement(name ="TwnNm" )
    private String twnNm;
    @XmlElement(name ="Ctry" )
    private String ctry;
}
