package com.pol.polbankingapp.model.response.AccountResponse;

import com.pol.polbankingapp.model.request.AccountCreation.FinanceInstInfo;
import com.pol.polbankingapp.model.request.AccountCreation.UserInfo;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name ="Customer")
@XmlAccessorType(XmlAccessType.FIELD)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Customer {

    @XmlElement(name = "UserInfo")
    private UserInfo user;

    @XmlElement(name = "FinInstnId")
    private FinanceInstInfo financeInstInfo;

    @XmlElement(name = "AccountInfo")
    private AccountInfo accountinfo;
}
