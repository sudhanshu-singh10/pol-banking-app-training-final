package com.pol.polbankingapp.controller;

import javax.validation.Valid;
import javax.xml.bind.JAXBException;

import com.pol.polbankingapp.exception.ResourceNotFoundException;
import com.pol.polbankingapp.model.request.AccountCreation.AccountUpdate;
import com.pol.polbankingapp.model.request.AccountCreation.DeleteAccInfo;
import com.pol.polbankingapp.model.request.AccountCreation.GetRequest;
import com.pol.polbankingapp.model.request.AccountCreation.DeleteAccInfo;
import com.pol.polbankingapp.service.AccountServiceImpl;

import com.pol.polbankingapp.service.UserServicesImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.pol.polbankingapp.model.request.AccountCreation.User;
import java.io.IOException;

@RestController
public class AccountController {

    @Autowired
    private UserServicesImpl userService;

    @Autowired
    private AccountServiceImpl service;

    @PostMapping(path ="/v1/accounts", consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<User> createAccount(@Valid @RequestBody User userac) throws JAXBException, IOException {

        if(userService.isAccountnotExists(userac)== true){
            userService.createAccount(userac);
            return new ResponseEntity<User>(HttpStatus.CREATED);
        } else{
            throw new ResourceNotFoundException( "Similar Account is already exists with the requested BANK against this PAN" );
        }

    }

    @GetMapping ( value="/v1/get/accounts" , produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity < Object > getRequest (@Valid @RequestBody GetRequest getRequest) throws JAXBException {
        Object obj = userService.getUser ( getRequest );
        return new ResponseEntity < Object> ( obj , HttpStatus.OK );
    }

    @PutMapping(path = "/v1/update/accounts", consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> updateAccount(@Valid @RequestBody AccountUpdate Accup) throws JAXBException, IOException {
        userService.updateAccount(Accup);
        return new ResponseEntity<String>("Account Updated Successfully", HttpStatus.OK);
    }


    @DeleteMapping(value = "/v1/delete/accounts", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> deleteAccount(@Valid @RequestBody DeleteAccInfo info) throws JAXBException, IOException {
        String response = userService.deleteAccount(info);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

}
