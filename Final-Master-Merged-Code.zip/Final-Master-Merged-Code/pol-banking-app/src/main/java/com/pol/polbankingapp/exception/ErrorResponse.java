package com.pol.polbankingapp.exception;

import lombok.Data;

import java.util.List;

@Data
public class ErrorResponse {
    private int statusCode;
    private String message;
    private List<String> details;
}
