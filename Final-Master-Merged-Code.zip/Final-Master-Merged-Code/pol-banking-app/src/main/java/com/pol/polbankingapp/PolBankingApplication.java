package com.pol.polbankingapp;

import com.pol.polbankingapp.model.response.AccountResponse.Customer;
import com.pol.polbankingapp.repository.AccDeletionRepo;
import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class PolBankingApplication {
    public static void main(String[] args) {
        SpringApplication.run(PolBankingApplication.class, args );
    }
    AccDeletionRepo deletionRepo = new AccDeletionRepo();
    Customer customer = deletionRepo.readFile("IN203456345");

}
