package com.pol.polbankingapp.model.request.AccountCreation;


import com.pol.polbankingapp.constant.POLConstants;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DeleteAccInfo {

    @NotEmpty(message = "BICFI code should not be empty")
    @Size(min = 11, max = 11, message = "BIFCI code should be of 11 characters")
    @Pattern(regexp = "^[A-Z]{6}[A-Z0-9]{5}$", message = "BankId should of 11 characters, first 6 characters should be upper case Alphabets, last 5 characters can be upper case numeric ")
    private String bicfi;

    @NotEmpty(message = "Pan id should not be empty")
    @Size(min = 10, max = 10, message = "PAN number should be of 10 characters")
    @Pattern(regexp = "^[A-Z0-9]{10}$" , message = "PAN number should be alpha numeric and size should be 10")
    private String pan;

    @Size(min = 11, max = 11, message = "IBAN number should be of 11 characters")
    @NotEmpty(message = "IBAN should not be empty")
    //@Pattern(regexp = "^[A-Z]{2}[0-9]{9}$" , message = "IBAN should start with country code and should be Alphanumeric ")
    private String iBan;

    @Size(min = 11, max = 11, message = "Reference IBAN number should be of 11 characters")
    //@Pattern(regexp = "^[A-Z]{2}[0-9]{9}$" , message = "IBAN should start with country code and should be Alphanumeric ")
    private String referenceAccIBan;

    @Size(min = 11, max = 11, message = "Reference BankId code should be of 11 characters")
    @Pattern(regexp = "^[A-Z]{6}[A-Z0-9]{5}$", message = " Reference BankId should of 11 characters, first 6 characters should be upper case Alphabets, last 5 characters can be upper case numeric ")
    private String referenceAccBankId;

    public String getiBan() {
        return iBan;
    }

    public void setiBan(String iBan) {
        this.iBan = iBan;
    }
}
=======
    @NotNull(message = "BICFI code should not be empty")
    @Pattern(regexp = "^[A-Z]{4}0[A-Z0-9]{6}$", message = "BankId should of 11 characters, first 4 characters should be upper case Alphabets, followed by 0, last six characters can be upper case Alphanumeric ")
    private String bankId;

    @NotNull(message = "Pan id should not be empty")
    @Pattern(regexp = "^[A-Z0-9]{10}$" , message = "PAN number should be alpha numeric and size should be 10")
    private String pan;

    @NotNull(message = "IBAN should not be empty")
    @Pattern(regexp = "\\d{11}" , message = "IBAN should start with country code and should be Alphanumeric ")
    private String iBan;

    @Pattern(regexp = "\\d{11}" , message = "IBAN should start with country code and should be Alphanumeric ")
    private String referenceAccIBan;

    @Pattern(regexp = "^[A-Z]{4}0[A-Z0-9]{6}$", message = "BankId should of 11 characters, first 4 characters should be upper case Alphabets, followed by 0, last six characters can be upper case Alphanumeric ")
    private String referenceAccBankId;
}


