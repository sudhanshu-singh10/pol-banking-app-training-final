package com.pol.polbankingapp.service;

import com.pol.polbankingapp.model.request.payment.PaymentTransfer;
import com.pol.polbankingapp.model.request.payment.AccountInfo;
import com.pol.polbankingapp.model.request.payment.Accounts;
import com.pol.polbankingapp.model.response.payment.CdtTrfTxInf;
import com.pol.polbankingapp.model.response.payment.FIToFICstmrCdtTrf;
import com.pol.polbankingapp.repository.MasterAccount;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.File;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
@Service
public class PaymentServiceImpl implements IPaymentService {

    @Autowired
    private MasterAccount masterAccount;
    public String intiateTranscation(PaymentTransfer paymentTransfer) {
        Accounts accounts;
        List<AccountInfo> accountInfos;
        Iterator<AccountInfo> iterator;
        AccountInfo accountInfo = null;
        int afterTranscaationDebitorBalance;
        int debitorSendingBalance = 0;
        int debitorCurrentBalance = 0;
        String response = null;
        accounts = masterAccount.readMasterAccountFile();
        accountInfos = accounts.getAccountInfo();
        iterator = accountInfos.iterator();
        while (iterator.hasNext()) {
            accountInfo = iterator.next();
            if (accountInfo.getIban().equals(paymentTransfer.getDebtoracc())) {
                System.out.println("DebitorAccount Details::" + accountInfo);
                if (accountInfo.getBalance() >= paymentTransfer.getAmount()) {
                    debitorSendingBalance = paymentTransfer.getAmount();
                    debitorCurrentBalance = accountInfo.getBalance();
                    System.out.println("Debitor Intial Balance::" + debitorCurrentBalance);
                } else
                    System.out.println("In sufficient funds transfer");
            } else if (accountInfo.getIban().equals(paymentTransfer.getCreditoracc())) {
                System.out.println("CreditorAccount Details::" + accountInfo);
                System.out.println("Creditor Initial Balance::" + accountInfo.getBalance());
                int creditedMoney = accountInfo.getBalance() + debitorSendingBalance;
                System.out.println("After credited Amount::" + creditedMoney);
                //break;
            } else {
                // System.out.println("Debitor/Creditor account details invalid!!");
                String errorResponseCreditor = paymentTransfer.getCreditoracc();
                String errorResponseDebitor = paymentTransfer.getDebtoracc();
                response = "!!Entered Debitor/Creditor details Invalid!!" + "DebitorACC:" + errorResponseDebitor + " " + "CreditorACC:" + errorResponseCreditor;
                break;
            }
            afterTranscaationDebitorBalance = debitorCurrentBalance - debitorSendingBalance;
            System.out.println("After transcation intiated Debitor Current Balance::" + afterTranscaationDebitorBalance);
            response = "Sucessfully transfered";


        }
        return response;
    }

    @Override
    public FIToFICstmrCdtTrf transactionDetailsbyid(long endToEndId) {

            String dirName="src/main/resources/Payments/";
            File dir = new File(dirName);
            boolean flag= false;
            File[] dir_Contents = dir.listFiles();
            for(int i=0;i<dir_Contents.length;i++)
            {
                if(dir_Contents[i].getName().equals(endToEndId+".xml"))
                {
                    System.out.println("File Present");

                    flag=true;
                    //return "File Found";
                    try {

                        File file = new File(dirName+"/"+endToEndId+".xml");
                        JAXBContext jaxbContext = JAXBContext.newInstance(FIToFICstmrCdtTrf.class);

                        Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
                        FIToFICstmrCdtTrf stud= (FIToFICstmrCdtTrf) jaxbUnmarshaller.unmarshal(file);
                        return  stud;

                    } catch (JAXBException e) {
                        e.printStackTrace();
                    }

                }
                else
                {
                    flag=false;
                }
                if(flag)
                {
                    break;
                }
                else
                {
                    if(i<dir_Contents.length) {
                        continue;
                    }
                }


            }
            System.out.println("File not found");
            return null;
        }

    @Override
    public FIToFICstmrCdtTrf transactionFileGeneration(FIToFICstmrCdtTrf ob) throws JAXBException {
        String dirName="src/main/resources/Payments/";
        Random rnd = new Random();
        int number = rnd.nextInt(999999999);

        JAXBContext jaxbContext = JAXBContext.newInstance(FIToFICstmrCdtTrf.class);

        Marshaller jaxbMarshallar = jaxbContext.createMarshaller();
        jaxbMarshallar.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,true);
        String s="T"+new Date();
        File file = new File(dirName+number+".xml");
        jaxbMarshallar.marshal(ob,file);
        jaxbMarshallar.marshal(ob,System.out);

        return ob;
    }
}