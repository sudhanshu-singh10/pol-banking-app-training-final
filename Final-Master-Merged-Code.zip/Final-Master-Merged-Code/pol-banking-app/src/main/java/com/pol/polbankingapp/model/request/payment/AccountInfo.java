package com.pol.polbankingapp.model.request.payment;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
public class AccountInfo {

   @XmlElement(name = "Pan")
   private  String pan ;
   @XmlElement(name = "IBAN")
   private String iban ;
   @XmlElement(name = "Balance")
   private int balance ;
   @XmlElement(name = "AccountStatus")
   private String account_status;
   @XmlElement(name = "AccountType")
   private String account_type;
   @XmlElement(name = "BICFI")
   private String bicfi;
}
