package com.pol.polbankingapp.model.request.payment;

import com.pol.polbankingapp.constant.POLConstants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.*;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PaymentTransfer {
    @NotEmpty(message = POLConstants.DEBITOR_ACC)
    @Pattern(regexp = POLConstants.ALPHA_NUMBERS, message = POLConstants.DBACC_VALIDATE)
    @Size(min = POLConstants.ACCNO_MIN, max = POLConstants.ACCNO_MAX, message = POLConstants.ACCNO_VALIDATION)
    private String debtoracc;

    @NotEmpty(message = POLConstants.DB_BICFI)
    @Pattern(regexp = POLConstants.BICFI_CODE_VALIDATE, message = POLConstants.BICFI_MESSAGE)
    private String bicfi;

    @NotEmpty(message = POLConstants.CREDITOR_ACC)
    @Pattern(regexp = POLConstants.ALPHA_NUMBERS, message = POLConstants.DBACC_VALIDATE)
    @Size(min = POLConstants.ACCNO_MIN, max = POLConstants.ACCNO_MAX, message = POLConstants.ACCNO_VALIDATION)
    private String creditoracc;

    @NotNull(message = POLConstants.AMOUNT)
    @Min(value = 1, message = POLConstants.AMOUNT_MSG)
    private int amount;

    private String method;

    @DateTimeFormat(pattern = POLConstants.DATE_FORMAT)
    @NotNull(message = POLConstants.DATE_MSG)
    private Date date;

    private String note;
}
