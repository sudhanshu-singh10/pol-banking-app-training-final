package com.pol.polbankingapp.repository;

import com.pol.polbankingapp.constant.POLConstants;
import com.pol.polbankingapp.exception.ResourceNotFoundException;
import com.pol.polbankingapp.model.request.AccountCreation.DeleteAccInfo;

import com.pol.polbankingapp.model.request.payment.Balance;
import com.pol.polbankingapp.model.response.AccountResponse.Customers;
import com.pol.polbankingapp.service.UserServicesImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;


@Repository
public class AccDeletionRepo {

    @Value("#{systemProperties['user.home']}")
    private String localPath;
    @Value("${accounts.local.path}")
    private String accountsPath;
    @Value("${balance.local.path}")
    private String balancePath;

    @Autowired
    UserServicesImpl userServices;

    Balance debtCsv = new Balance();

    Balance credCsv = new Balance();

    BalanceCSV balanceCSV = new BalanceCSV();

    BalanceCSV refBalanceSCV = new BalanceCSV();

    // path for the directory having AccountCreation.xml

    // Method for finding file
    public String findFile(String iBan) throws ResourceNotFoundException {

        File dir = new File(localPath + accountsPath);

        String[] fileList = dir.list();
        String fileName = iBan + ".xml";
        int flag = 0;
        if (fileList != null) {
            for (int i = 0; i < fileList.length; i++) {
                if (fileName.equals(fileList[i])) {
                    flag = 1;
                    break;

                }

            }
            if (flag == 1) {
                System.out.println(fileName);
                return fileName;
            } else
                throw new ResourceNotFoundException("Account does not exist");
            // return "File not present";
        } else
            throw new ResourceNotFoundException("Directory is empty");
        // return "Directory is empty";

    }

    // Method for reading file
    public Customers readFile(String fileName) throws ResourceNotFoundException {

        File dir = new File(localPath + accountsPath);

        File accCreationFile = new File(dir + "/" + fileName);

        JAXBContext jaxbContext;
        try {
            jaxbContext = JAXBContext.newInstance(Customers.class);
            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
            Customers customer = (Customers) unmarshaller.unmarshal(accCreationFile);
            System.out.println(customer);
            return customer;
        } catch (Exception e) {

            e.printStackTrace();
        }

        return null;
    }

    public String checkValues(Customers customer, DeleteAccInfo info, String fileName)
            throws JAXBException, IOException {
        File dir = new File(localPath + accountsPath);
        File balanceDir = new File(localPath + balancePath);

        File accCreationFile = new File(dir + "/" + fileName);

        // condition: user did not provide the reference account no
        if (customer.getAccountinfo().getIban().equals(info.getiBan())
                && customer.getFinanceInstInfo().getBicfi().equals(POLConstants.Bicfi.valueOf(info.getBicfi()))
                && customer.getUser().getPanid().equals(info.getPan())

        ) {

            // checking account status
            checkAccStatus(customer);

            // check if user provides ref Account
            if (info.getReferenceAccIBan() != null && info.getReferenceAccBankId() != null) {
             // if (info.getReferenceAccIBan() != null) {

                String refAccIBan = findFile(info.getReferenceAccIBan());

                Customers refCustomer = readFile(refAccIBan);

                // method for transferring money to another reference account
                if (refCustomer.getAccountinfo().getIban().equals(info.getReferenceAccIBan()) && refCustomer
                        .getFinanceInstInfo().getBicfi().equals(POLConstants.Bicfi.valueOf(info.getReferenceAccBankId()))) {

                    // check refAccount status
                    //checkAccStatus(refCustomer);
                    if (refCustomer.getAccountinfo().getAccountStatus().equals(POLConstants.AccStts.ACTIVE)) {


                        // creating balance object

                        debtCsv.setTransactionAccountId(info.getiBan());
                        debtCsv.setSettlementAmount("");
                        debtCsv.setAccountType(String.valueOf(customer.getAccountinfo().getAccountType()));
                        debtCsv.setBalance("");
                        debtCsv.setStatus("Sucess");
                        // DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
                        Date date = new Date();
                        debtCsv.setTransactionDate(date);
                        debtCsv.setTransactionType("debit");

                        balanceCSV.finalSettlementBeforeDeletion(balanceDir + "/" + info.getiBan() + ".csv", debtCsv);

                        credCsv.setTransactionAccountId(info.getReferenceAccIBan());
                        credCsv.setSettlementAmount(debtCsv.getSettlementAmount());
                        credCsv.setAccountType(String.valueOf(refCustomer.getAccountinfo().getAccountType()));
                        credCsv.setBalance("");
                        credCsv.setStatus("Sucess");
//                    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
//                    Date date = new Date();
                        credCsv.setTransactionDate(date);
                        credCsv.setTransactionType("credit");
                        refBalanceSCV.finalSettlementBeforeDeletion(balanceDir + "/" + info.getReferenceAccIBan() + ".csv",
                                credCsv);

                        customer.getAccountinfo().setAccountStatus(POLConstants.AccStts.INACTIVE);


                        // method for updating accCreation file
                        updateFile(customer, accCreationFile);

                        userServices.updatemasterfile(info);

                        return "Account is deleted and Money is transferred to Reference Account";
                    } else {
                        throw new ResourceNotFoundException("Reference Account is Inactive");
                    }
                }
            } else {

                // creating balance object

                debtCsv.setTransactionAccountId(info.getiBan());
                debtCsv.setSettlementAmount("");
                debtCsv.setAccountType(String.valueOf(customer.getAccountinfo().getAccountType()));
                debtCsv.setBalance("");
                debtCsv.setStatus("Success");
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
                Date date = new Date();
                debtCsv.setTransactionDate(date);
                debtCsv.setTransactionType("debit");

                balanceCSV.finalSettlementBeforeDeletion(balanceDir + "/" + info.getiBan() + ".csv", debtCsv);

                customer.getAccountinfo().setAccountStatus(POLConstants.AccStts.INACTIVE);

                // method for updating accCreation file
                updateFile(customer, accCreationFile);

                userServices.updatemasterfile(info);

                // method for transferring money to another account

                return "Account is deleted and Money has been transferred to you via check";

            }

        }
        return "Account validation failed: please enter correct information ";

    }

    // method for account status checking
    public boolean checkAccStatus(Customers customer) {
        if (customer.getAccountinfo().getAccountStatus().equals(POLConstants.AccStts.ACTIVE)) {

            return true;

        } else
            throw new ResourceNotFoundException("Account is Inactive");
    }

    // method for updating file
    public void updateFile(Customers customer, File file) throws JAXBException {
        JAXBContext jaxbContext = JAXBContext.newInstance(Customers.class);

        Marshaller marshaller = jaxbContext.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
        marshaller.marshal(customer, file);

    }
}
