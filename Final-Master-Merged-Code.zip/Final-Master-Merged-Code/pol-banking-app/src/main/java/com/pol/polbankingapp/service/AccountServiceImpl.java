package com.pol.polbankingapp.service;

import com.pol.polbankingapp.model.request.AccountCreation.DeleteAccInfo;
import com.pol.polbankingapp.model.response.AccountResponse.Customer;
import com.pol.polbankingapp.repository.AccDeletionRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.xml.bind.JAXBException;

@Service
public class AccountServiceImpl implements IAccountService{

    @Autowired
    private AccDeletionRepo deletionRepo;

    @Override
    public boolean deleteAccount(DeleteAccInfo info) throws JAXBException {

        String accCreationFile = deletionRepo.findFile(info.getIBan());
        Customer customer = deletionRepo.readFile(accCreationFile);
        deletionRepo.checkValues(customer, info, accCreationFile);


        return true;
    }
}
