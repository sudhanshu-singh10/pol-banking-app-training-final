package com.pol.polbankingapp.repository;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.pol.polbankingapp.constant.POLConstants;
import com.pol.polbankingapp.model.request.payment.Balance;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.*;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

@Component
public class BalanceCSV {

    @Value("#{systemProperties['user.home']}")
    private String localPath;
    @Value("${balance.local.path}")
    private String path;

    public void createBalanceCSV(String iban, String initialBalance, POLConstants.AccType accountType) throws IOException {
        try {

            CSVWriter pw = new CSVWriter(new FileWriter(localPath+path + iban + ".csv", true));
            String[] sb = {"Transaction_AccountId", "Settlement_Amount", "Transaction_Type", "Transaction Date (DD-MM-YY HH:MM:SS)", "Balance", "Status", "Account_type"};
            pw.writeNext(sb);
            pw.close();
            System.out.println("Finished CSV");

        } catch (Exception exception) {

        }
        Balance balObj = new Balance();
        balObj.setTransactionAccountId(iban);
        balObj.setSettlementAmount("");
        balObj.setTransactionType("");
        //DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        balObj.setTransactionDate(date);
        balObj.setBalance(initialBalance);
        balObj.setStatus("Sucess");
        balObj.setAccountType(String.valueOf(accountType));

        BalanceCSV.writeTOCSV(localPath+path + iban + ".csv", balObj);

    }

    public static BalanceCSV writeTOCSV(String filename, Balance balObj) throws IOException {
        String[] obj = BalanceCSV.toStringArray(balObj);
        System.out.println(obj);
        CSVReader reader = null;
        try {
            try {
                reader = new CSVReader(new FileReader(filename));
            } catch (FileNotFoundException fileNotFoundException) {
                fileNotFoundException.printStackTrace();
            }
            CSVWriter writer = new CSVWriter(new FileWriter(filename, true));
            //Writing data to a csv file

            writer.writeNext(obj);
            writer.flush();
        } finally {
        }
        return null;
    }

    // For Delete Request
    public BalanceCSV finalSettlementBeforeDeletion(String filename, Balance balObj) throws IOException {

        String[] obj = BalanceCSV.toStringArray(balObj);

        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {

            String lastLine = "";
            String line = "";

            while ((line = br.readLine()) != null) {
                lastLine = line;
            }
            System.out.println(lastLine);

            String[] str = lastLine.split(",");
            System.out.println(str);
            String dummy = str[4].trim();
            //String dummy = str[4].substring(0,str[4].length()-1);
            Integer value = Integer.valueOf(dummy).intValue();
            System.out.println(value);

            String updatedBalance = "";
            try {
                if (balObj.getTransactionType().equalsIgnoreCase("credit")) {
                    try {

                        updatedBalance = String.valueOf(value + Integer.parseInt(balObj.getSettlementAmount()));
                    } catch (NumberFormatException nfe) {
                        nfe.printStackTrace();
                    }
                } else
                    try {
                        balObj.setSettlementAmount(String.valueOf(value));
                        updatedBalance = String.valueOf(value - Integer.parseInt(balObj.getSettlementAmount()));
                    } catch (NumberFormatException nfe) {
                        nfe.printStackTrace();
                    }
                obj[1] = balObj.getSettlementAmount();
                obj[4] = updatedBalance;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        CSVReader reader = null;

        try {

            try {
                reader = new CSVReader(new FileReader(filename));
            } catch (FileNotFoundException fileNotFoundException) {
                fileNotFoundException.printStackTrace();
            }

            CSVWriter writer = new CSVWriter(new FileWriter(filename, true));
            // Writing data to a csv file

            writer.writeNext(obj);
            writer.flush();
        } finally {

        }

        return null;
    }

    public static String[] toStringArray(Balance balObj) {
        String[] obj = new String[7];
        obj[0] = balObj.getTransactionAccountId();
        obj[1] = balObj.getSettlementAmount();
        obj[2] = balObj.getTransactionType();
        Format formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date dt = balObj.getTransactionDate();
        obj[3] = formatter.format(dt);
        obj[4] = balObj.getBalance();
        obj[5] = balObj.getStatus();
        obj[6] = balObj.getAccountType();
        return obj;
    }

}
