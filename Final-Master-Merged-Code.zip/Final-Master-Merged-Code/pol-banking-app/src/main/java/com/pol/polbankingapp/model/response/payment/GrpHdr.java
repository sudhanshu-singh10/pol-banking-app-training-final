package com.pol.polbankingapp.model.response.payment;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.Date;
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@XmlRootElement
public class GrpHdr {
    private int msgId;
    private Date creDtTm;
    private int nbOfTxs;
}
