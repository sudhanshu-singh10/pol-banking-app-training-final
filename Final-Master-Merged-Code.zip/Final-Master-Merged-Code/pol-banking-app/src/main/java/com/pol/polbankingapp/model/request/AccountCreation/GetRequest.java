package com.pol.polbankingapp.model.request.AccountCreation;

import com.pol.polbankingapp.constant.POLConstants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class GetRequest {

    @NotNull(message = "Please enter vaild account number")
    //@Pattern(regexp = "^[A-Z]{5}[A-Z0-9]{6}$", message = "BankId should of 11 characters, first 4 characters should be upper case Alphabets, followed by 0, last six characters can be upper case Alphanumeric ")
    private String bankId;

    public String getBankId () {
        return bankId;
    }

    public void setBankId ( String bankId ) {
        this.bankId = bankId;
    }

    @NotNull(message = POLConstants.PAN_MSG)
    @Pattern(regexp = "^[A-Z0-9]{10}$" , message = "PAN number should be alpha numeric and size should be 10")
    private String pan;

    public String getPan () {
        return pan;
    }

    public void setPan ( String pan ) {
        this.pan = pan;
    }

    @NotNull(message = "IBAN should not be empty")
    @Pattern(regexp = "\\d{11}" , message = "IBAN should start with country code and should be Alphanumeric ")
    private String iBan;

    public String getiBan () {
        return iBan;
    }

    public void setiBan ( String iBan ) {
        this.iBan = iBan;
    }
}
