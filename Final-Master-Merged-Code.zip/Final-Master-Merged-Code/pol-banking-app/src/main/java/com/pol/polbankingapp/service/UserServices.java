package com.pol.polbankingapp.service;

import com.pol.polbankingapp.model.request.AccountCreation.AccountUpdate;
import com.pol.polbankingapp.model.request.AccountCreation.DeleteAccInfo;
import com.pol.polbankingapp.model.request.AccountCreation.GetRequest;
import com.pol.polbankingapp.model.request.AccountCreation.User;

import javax.xml.bind.JAXBException;
import java.io.IOException;

public interface UserServices {

    public Object createAccount(User userrequest) throws JAXBException, IOException;

    public Object getUser(GetRequest getRequest) throws JAXBException;

    public String updateAccount(AccountUpdate accup) throws JAXBException, IOException;

    public String deleteAccount(DeleteAccInfo info) throws JAXBException, IOException;
}
