package com.pol.polbankingapp.model.response.payment;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class TranscationResponse {
    private FIToFICstmrCdtTrf fIToFICstmrCdtTrf;
    private Cdtr cdtr;
    private Dbtr dbtr;
    private String rmtInf;
    private String transactionSts;
}
