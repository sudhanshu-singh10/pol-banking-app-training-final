package com.pol.polbankingapp.service;

import com.pol.polbankingapp.model.request.AccountCreation.DeleteAccInfo;

import javax.xml.bind.JAXBException;

public interface IAccountService {
    public boolean deleteAccount(DeleteAccInfo info) throws JAXBException;
}
