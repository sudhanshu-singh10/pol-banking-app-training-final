package com.pol.polbankingapp.controller;

import com.pol.polbankingapp.model.request.PaymentTransfer;
import com.pol.polbankingapp.model.response.payment.*;
import com.pol.polbankingapp.service.IPaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.xml.bind.JAXBException;
import java.util.Date;

@RestController
@RequestMapping("/payments")
public class PaymentController {
    @Autowired
    private IPaymentService paymentService;

    private FIToFICstmrCdtTrf ob;




    @RequestMapping(value = "/transction", method = RequestMethod.POST, produces = {"application/xml", "text/xml", "application/json"}, consumes = {"application/xml", "text/xml", "application/json"})
    @ResponseBody
    public ResponseEntity<Object> intiatePaymentTranscation(@Valid @RequestBody PaymentTransfer paymentTransfer) {
        String response;
        response= paymentService.intiateTranscation(paymentTransfer);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @RequestMapping(value="/{endToEndId}", method = RequestMethod.GET, produces = {"application/json"},consumes = {"application/xml", "text/xml", "application/json"})
    public FIToFICstmrCdtTrf transactionDetails(@PathVariable("endToEndId")long endToEndId)
    {
        FIToFICstmrCdtTrf tr= paymentService.transactionDetailsbyid(endToEndId);
        return tr;
    }

    @RequestMapping(value="/generateTxnfile",method = RequestMethod.GET, produces = {"application/json"})
    public FIToFICstmrCdtTrf generateTransactionFile(FIToFICstmrCdtTrf ob) throws JAXBException {
      ob = new FIToFICstmrCdtTrf(
                new CdtTrfTxInf(87653421l,"IMPS",20000,
                        new Date(),
                        new Dbtr("Harshad",
                                new PstlAdr("Mayur Park Road","123","3456876","Hudco","Aurangabad","Maharashtra")
                                ,new DbtrAcct("IN231234567",
                                new DbtrAgt("HDFC11008"))),
                        new Cdtr("Shubham",
                                new PstlAdr("Mayur Park Road","123","3456876","Hudco","Aurangabad","Maharashtra")
                                ,new CdtrAcct("IN231234567",
                                new CdtrAgt("HDFC11008"))),
                        "Flat Rent Money",
                        "Success"));
        FIToFICstmrCdtTrf trDetails = paymentService.transactionFileGeneration(ob);
        return trDetails;
    }


}