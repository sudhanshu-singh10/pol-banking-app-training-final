package com.pol.polbankingapp.service;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import com.pol.polbankingapp.constant.POLConstants;
import com.pol.polbankingapp.exception.ResourceNotFoundException;
import com.pol.polbankingapp.model.request.AccountCreation.*;
import com.pol.polbankingapp.model.response.AccountResponse.*;
import com.pol.polbankingapp.repository.AccDeletionRepo;

import com.pol.polbankingapp.model.request.AccountCreation.AddressInfo;
import com.pol.polbankingapp.model.request.AccountCreation.FinanceInstInfo;
import com.pol.polbankingapp.model.request.AccountCreation.UserInfo;
import com.pol.polbankingapp.model.response.AccountResponse.AccountInfo;
import com.pol.polbankingapp.model.response.AccountResponse.Customer;
import com.pol.polbankingapp.repository.AccountCreation;
import com.pol.polbankingapp.repository.BalanceCSV;
import org.springframework.beans.factory.annotation.Autowired;
import com.pol.polbankingapp.repository.MasterAccount;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.validation.Valid;
import javax.xml.bind.JAXBException;

@Service
public class UserServicesImpl implements com.pol.polbankingapp.service.UserServices {

    @Autowired
    AccountCreation accountCreation;
    @Autowired
    MasterAccount masterAccount;

    @Value("#{systemProperties['user.home']}")
    private String localPath;
    @Value("${accounts.local.path}")
    private String path;

    @Autowired
    BalanceCSV balanceCSV;

    @Autowired
    private AccDeletionRepo deletionRepo;

    public String Iban;
    public int Customer_ID;
    public int exist_custm_id;
    public POLConstants.Bicfi bicfi;

    public Object createAccount(User userrequest) throws JAXBException, IOException {


        Customer customer = new Customer();
        UserInfo userInfo = new UserInfo();
        AccountInfo accountinfo = new AccountInfo();
        FinanceInstInfo financeInstInfo = new FinanceInstInfo();
        AddressInfo addres = new AddressInfo();
        MasterAccounts accounts = new MasterAccounts();
        MasterAccountInfo masterAccountInfo = new MasterAccountInfo();


        userInfo.setFirst_name(userrequest.getFirstName());
        userInfo.setLast_name(userrequest.getLastName());
        userInfo.setDob(userrequest.getDob().toString());
        userInfo.setEmail(userrequest.getEmail());
        userInfo.setAadhar(userrequest.getAadhar());
        userInfo.setMobile(userrequest.getMobileNumber());
        userInfo.setPanid(userrequest.getPan());


        addres.setCtry(userrequest.getCountry());
        addres.setPstCd(userrequest.getPostCode());
        addres.setStrtNm(userrequest.getStreetName());
        addres.setTwnNm(userrequest.getCity());
        String Bank = userrequest.getBankName().toUpperCase();
        financeInstInfo.setBank_name(Bank);

        if (Bank.equals("HDFC")) {
            financeInstInfo.setBicfi(POLConstants.Bicfi.HDFCIN22944);
            bicfi = financeInstInfo.getBicfi();
        } else if (Bank.equals("ICICI")) {
            financeInstInfo.setBicfi(POLConstants.Bicfi.ICICIN33495);
            bicfi = financeInstInfo.getBicfi();
        } else if (Bank.equals("KOTAK")) {
            financeInstInfo.setBicfi(POLConstants.Bicfi.KOTAIN44622);
            bicfi = financeInstInfo.getBicfi();
        }

        accountinfo.setAccountType(userrequest.getAccType());
        accountinfo.setCuurency(userrequest.getCuurency());
        accountinfo.setInitialBalance(String.valueOf(userrequest.getOpeningBalance()));
        accountinfo.setAccountStatus(POLConstants.AccStts.ACTIVE);
        accountinfo.setCreDtTm(LocalDateTime.now().withNano(0).toString());
        accountinfo.setIban(String.valueOf(createIBAN()));
        //accountinfo.setIban(accountCreation.getIBAN());

        customer.setUser(userInfo);
        customer.setAccountinfo(accountinfo);
        customer.setFinanceInstInfo(financeInstInfo);
        userInfo.setPstlAdr(addres);
        if (isCustomerIdexists(userrequest)) {
            userInfo.setCustomer_id(exist_custm_id);
            masterAccountInfo.setCustomer_id(exist_custm_id);
        } else {
            userInfo.setCustomer_id(getCustomerID());
            masterAccountInfo.setCustomer_id(Customer_ID);
        }
        accountCreation.jaxbObjectToXML(customer, Iban);

        List<MasterAccountInfo> master = new ArrayList<>();
        masterAccountInfo.setAccountType(userrequest.getAccType());
        masterAccountInfo.setCuurency(userrequest.getCuurency());
        masterAccountInfo.setInitialBalance(String.valueOf(userrequest.getOpeningBalance()));
        masterAccountInfo.setAccountStatus(POLConstants.AccStts.ACTIVE);
        masterAccountInfo.setCreDtTm(LocalDateTime.now().withNano(0).toString());
        masterAccountInfo.setIban(String.valueOf(Iban));
        masterAccountInfo.setPanid(userrequest.getPan());
        //  masterAccountInfo.setCustomer_id(Customer_ID);
        masterAccountInfo.setBicfi(bicfi);

        master.add(masterAccountInfo);
        //accounts.setAccountInfo(master);

        Map<String, MasterAccountInfo> mastermap = new HashMap<>();
        mastermap.put(String.valueOf(Iban), masterAccountInfo);

        //MasterAccount masterAccount = new MasterAccount();


        MasterAccounts existingmastermap = masterAccount.getListofExistingAccount();
        if (mastermap.containsKey(existingmastermap)) {
                /*
                Here i have checked the generated iban with existings but instead of this
                you need to check with the requested iban with existings iban
                and Implement the update operation here.
                 */
        } else {
            Map<String, MasterAccountInfo> mas = new HashMap<>();
            for (Map.Entry<String, MasterAccountInfo> mapEntry : existingmastermap.getMasterAccountMap().entrySet()) {
                System.out.println("key" + mapEntry.getKey() + " value" + mapEntry.getValue());
                mas.put(mapEntry.getKey(), mapEntry.getValue());
            }
            mas.put(String.valueOf(Iban), masterAccountInfo);
            mas.putAll(existingmastermap.getMasterAccountMap());
            accounts.setMasterAccountMap((Map<String, MasterAccountInfo>) mas);
            masterAccount.MasterjaxbObjectToXML(accounts);
        }

        accountCreation.jaxbObjectToXML(customer, Iban);
        balanceCSV.createBalanceCSV(accountinfo.getIban(), accountinfo.getInitialBalance(), accountinfo.getAccountType());
        return accountCreation;
    }


    public String createIBAN() {

        Random rnd = new Random();
//        long IBAN = rnd.nextInt(1_000_000_000)               // Last 9 digits
//                + (rnd.nextInt(50) + 10) * 1_000_000_000L;      // First 2 digits
//        this.Iban = IBAN;

        String IBAN = "IN"+(10 + new Random().nextInt(90))+(1000000 + new Random().nextInt(900000));
        this.Iban = IBAN ;
        //setIban(String.valueOf(IBAN));
        return IBAN;
    }

    public int getCustomerID() {
        int customID = (100000 + new Random().nextInt(90000));
        this.Customer_ID = customID;
        return customID;
    }


    @Override
    public Customers getUser(GetRequest getRequest) throws JAXBException {
        Customers cus = new Customers();
        String accCreationFile = findFile(getRequest.getiBan());
        System.out.println(accCreationFile);
        cus = accountCreation.readFile(accCreationFile);
        checkAccStatus(cus);


        return cus;

    }

    public String findFile(String iBan) {

        File dir = new File(localPath + path);
        String[] fileList = dir.list();
        String fileName = iBan + ".xml";
        File file = new File(fileName);
        int flag = 0;
        if (fileList != null) {
            for (int i = 0; i < fileList.length; i++) {
                if (fileList[i].contains(fileName)) {
                    flag = 1;
                    break;

                }

            }
            if (flag == 1) {
                return fileName;
            } else {
                throw new ResourceNotFoundException("Account is not present");
            }
            //return "File not present";
        } else
            throw new ResourceNotFoundException("No User is found with this IBAN");
        //return "Directory is empty";

    }


    public Customers checkAccStatus(Customers cus) {
        if (cus.getAccountinfo().getAccountStatus().equals(POLConstants.AccStts.ACTIVE)) {

            return cus;

        } else throw new ResourceNotFoundException("Account is Inactive");
    }

    // For update account
    public String updateAccount(AccountUpdate accup) throws JAXBException, IOException {
        String updateiban = accup.getIban();


        String Fname = findFile(updateiban);

        Customers customer = accountCreation.readFile(Fname);

        checkAccStatus(customer);

        UserInfo newuser = customer.getUser();
        AccountInfo accountinfo = customer.getAccountinfo();
        FinanceInstInfo financeInstInfo = customer.getFinanceInstInfo();

        AddressInfo addres = new AddressInfo();


        addres.setPstCd(accup.getPostCode());
        addres.setStrtNm(accup.getStreetName());
        addres.setTwnNm(accup.getCity());
        //addres.setState(accup.getState());
        //addres.setBldgNb(accup.getBldgNb());

        newuser.setMobile(accup.getMobileNumber());

        customer.setUser(newuser);
        customer.setAccountinfo(accountinfo);
        customer.setFinanceInstInfo(financeInstInfo);
        newuser.setPstlAdr(addres);


        accountCreation.jaxbObjectToXML(customer, updateiban);

        return "Account Updated Succesfully";


    }

    public Boolean isAccountnotExists(@Valid User userac) throws JAXBException {

        MasterAccounts existingmastermap = masterAccount.getListofExistingAccount();

        Multimap<String, Mastervalidation> mastervalidation = ArrayListMultimap.create();

        for (Map.Entry<String, MasterAccountInfo> mapEntry : existingmastermap.getMasterAccountMap().entrySet()) {
            System.out.println("key" + mapEntry.getKey() + " value" + mapEntry.getValue());
            mastervalidation.put(mapEntry.getValue().getPanid(), new Mastervalidation(mapEntry.getValue().getAccountType(), mapEntry.getValue().getBicfi(), mapEntry.getValue().getAccountStatus()));
            System.out.println("genrateing mastervalidation map" + mastervalidation.toString());
        }


        //if(cloningexistingmaster.containsValue(userac.getPan()) && cloningexistingmaster.containsValue(userac.getAccType())&& cloningexistingmaster.containsValue(userac.getBicfi())){
        if (mastervalidation.containsKey(userac.getPan())) {

            if (userac.getBankName().equals("HDFC")) {
                bicfi = POLConstants.Bicfi.HDFCIN22944;
            } else if (userac.getBankName().equals("ICICI")) {
                bicfi = POLConstants.Bicfi.ICICIN33495;
            } else if (userac.getBankName().equals("KOTAK")) {
                bicfi = POLConstants.Bicfi.KOTAIN44622;
            }
            if (mastervalidation.get(userac.getPan()).stream().anyMatch(x -> x.getBicfi().equals(bicfi))) {
                if (mastervalidation.get(userac.getPan()).stream().allMatch(x -> !x.getAccType().equals(userac.getAccType())) && mastervalidation.get(userac.getPan()).stream().anyMatch(x -> x.getAccountStatus().equals(POLConstants.AccStts.INACTIVE))) {

                    return true;
                } else if (mastervalidation.get(userac.getPan()).stream().allMatch(x -> x.getAccType().equals(userac.getAccountType()))) {

                    if (mastervalidation.get(userac.getPan()).stream().anyMatch(x -> x.getAccountStatus().equals(POLConstants.AccStts.ACTIVE))) {
                        return false;
                    }
                }
                return true;
            }
            return true;
        }
        return true;
    }

    public Boolean isCustomerIdexists(User userac) throws JAXBException {

        MasterAccounts existingmastermap = masterAccount.getListofExistingAccount();

        for (Map.Entry<String, MasterAccountInfo> mapEntry : existingmastermap.getMasterAccountMap().entrySet()) {
            if (mapEntry.getValue().getPanid().equals(userac.getPan())) {
                if (userac.getBankName().equals("HDFC")) {
                    bicfi = POLConstants.Bicfi.HDFCIN22944;
                } else if (userac.getBankName().equals("ICICI")) {
                    bicfi = POLConstants.Bicfi.ICICIN33495;
                } else if (userac.getBankName().equals("KOTAK")) {
                    bicfi = POLConstants.Bicfi.KOTAIN44622;
                }
                if (mapEntry.getValue().getBicfi().equals(bicfi)) {
                    if (mapEntry.getValue().getAccountStatus().equals(POLConstants.AccStts.ACTIVE)) {
                        this.exist_custm_id = mapEntry.getValue().getCustomer_id();
                        return true;
                    }
                    continue;
                }
                continue;
            }
            continue;
        }
        return false;
    }

    public String deleteAccount(DeleteAccInfo info) throws JAXBException, IOException {

        String iBan = info.getiBan();
        String accCreationFile = deletionRepo.findFile(iBan);
        Customers customer = deletionRepo.readFile(accCreationFile);
        String string = deletionRepo.checkValues(customer, info, accCreationFile);
        System.out.println(string);

        return string;
    }

    // Update Master file for balance transfer on Delete request
    public void updatemasterfile(DeleteAccInfo deleteAccInfo) throws JAXBException, IOException {

        MasterAccounts existingmastermap = masterAccount.getListofExistingAccount();

            // if reference account exists
            if (existingmastermap.getMasterAccountMap().containsKey(deleteAccInfo.getReferenceAccIBan())) {
//                    if (deleteAccInfo.getBankName().equals("HDFC")) {
//                        bicfi = POLConstants.Bicfi.HDFCIN22944;
//                    } else if (userac.getBankName().equals("ICICI")) {
//                        bicfi = POLConstants.Bicfi.ICICIN33495;
//                    } else if (userac.getBankName().equals("KOTAK")) {
//                        bicfi = POLConstants.Bicfi.KOTAIN44622;
//                    }
                if (existingmastermap.getMasterAccountMap().get(deleteAccInfo.getReferenceAccIBan()).getBicfi().equals(POLConstants.Bicfi.valueOf(deleteAccInfo.getReferenceAccBankId()))){

                    if (existingmastermap.getMasterAccountMap().get(deleteAccInfo.getReferenceAccIBan()).getAccountStatus().equals(POLConstants.AccStts.ACTIVE)){
                            //existingmastermap.getMasterAccountMap().values().stream().anyMatch(x -> x.getAccountStatus().equals(POLConstants.AccStts.ACTIVE))){

                       // String existingAccountbalance = existingmastermap.getMasterAccountMap().get(deleteAccInfo.getReferenceAccBankId()).getInitialBalance();
                        int existingAccountbalance = getBalancefrommaster(deleteAccInfo.getReferenceAccIBan());

                        int currentaccountbalance = getBalancefrommaster(deleteAccInfo.getiBan());

                        //int updatedbalnce = Integer.parseInt(existingAccountbalance) + currentaccountbalance;

                        int updatedbalnce = existingAccountbalance + currentaccountbalance;
                        MasterAccountInfo masterAccountInfo = new MasterAccountInfo();

                       //existingmastermap.getMasterMap().values().stream().map(x-> x.setInitialBalance(String.valueOf(updatedbalnce)));
                        existingmastermap.getMasterMap().get(deleteAccInfo.getReferenceAccIBan()).setInitialBalance(String.valueOf(updatedbalnce));
                        existingmastermap.getMasterMap().get(deleteAccInfo.getiBan()).setInitialBalance("0");
                        existingmastermap.getMasterMap().get(deleteAccInfo.getiBan()).setAccountStatus(POLConstants.AccStts.INACTIVE);
                        masterAccount.MasterjaxbObjectToXML(existingmastermap);
                    }

                }

            }else {
                existingmastermap.getMasterMap().get(deleteAccInfo.getiBan()).setInitialBalance("0");
                existingmastermap.getMasterMap().get(deleteAccInfo.getiBan()).setAccountStatus(POLConstants.AccStts.INACTIVE);
                masterAccount.MasterjaxbObjectToXML(existingmastermap);
        }
    }

    public int getBalancefrommaster(String iban) throws JAXBException {

        MasterAccounts existingmastermap = masterAccount.getListofExistingAccount();

        String balance =existingmastermap.getMasterAccountMap().get(iban).getInitialBalance();
//
//        String requestedaccountalance = null;
//        for (Map.Entry<String, MasterAccountInfo> mapEntry : existingmastermap.getMasterAccountMap().entrySet()) {
//            if (mapEntry.getKey().equals(iban)){
//             requestedaccountalance  = mapEntry.getValue().getInitialBalance();
//            }
//            continue;
//        }
        return Integer.parseInt(balance);
    }
}