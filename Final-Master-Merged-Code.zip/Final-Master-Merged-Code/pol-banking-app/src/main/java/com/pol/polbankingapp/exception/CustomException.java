package com.pol.polbankingapp.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@Data
@NoArgsConstructor
@AllArgsConstructor
@RestControllerAdvice
public class CustomException extends RuntimeException {
    private String message;
    private HttpStatus status;
}
