package com.pol.polbankingapp.model.request.AccountCreation;

import com.pol.polbankingapp.constant.POLConstants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "FinInstnId")
//@XmlType(propOrder = {
//        "BICFI",
//        "LEI"
//})
@XmlAccessorType(XmlAccessType.FIELD)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class FinanceInstInfo {

    @XmlElement(name = "BICFI")
    private POLConstants.Bicfi bicfi;
    @XmlElement(name = "LEI")
    private String bank_name;
}
